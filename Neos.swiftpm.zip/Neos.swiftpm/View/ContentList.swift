import Foundation

class ContentLists {
    
    let navID: String
    
    init(navID: String) {
        self.navID = navID
    }
    
    lazy var datatypeList: [LearningContent] = [
        LearningContent(id: UUID(), content: "Understanding Integers: A Brief Overview", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "Programming's basic datatype, integers, represent whole numbers exclusively—that is, without any fractional part. Integers are the building blocks of numerical operations in the Neos programming language, providing an exact method of storing and manipulating numerical data. Numerical values are essential for defining the logic and operation of Neos programmes, whether they are used for counting objects or doing arithmetic operations.", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "10", contentType: LearningDetailsContentType.code, navID: navID),
        
        LearningContent(id: UUID(), content: "Understanding Floats: A Brief Overview", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "Programming numbers with a fractional component are represented using floats, a standard datatype. Floats in the Neos programming language offer a flexible method of handling decimal values, which is necessary for accurate calculations in a variety of scenarios. It is essential to comprehend floats in order to appropriately represent real-world data in Neos programmes, from scientific simulations to financial computations.", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "3.14", contentType: LearningDetailsContentType.code, navID: navID),
        
        LearningContent(id: UUID(), content: "Understanding Doubles: A Brief Overview", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "Numbers with a fractional component are also represented using doubles, a common datatype in programming. Doubles are more precise than floats in the Neos programming language, which makes them appropriate for applications that demand great calculation accuracy. Knowing doubles is crucial for guaranteeing correct depiction of real-world data in Neos programmes, from intricate mathematical calculations to exact scientific measurements.", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "3.14159265358979323846", contentType: LearningDetailsContentType.code, navID: navID),
        
        LearningContent(id: UUID(), content: "Understanding Booleans: A Brief Overview", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "Programming's core datatype, booleans, represent logical values that might be true or false. Booleans are necessary in the Neos programming language to manage programme flow and make condition-based decisions. Comprehending booleans is essential for creating logic and managing behaviour in Neos programmes, encompassing conditional statements and logical operations.", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "true\nfalse", contentType: LearningDetailsContentType.code, navID: navID),
        
        LearningContent(id: UUID(), content: "Understanding Strings: A Brief Overview", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "Sequences of characters are represented by strings, a fundamental datatype in programming. Strings are flexible containers for textual data in the Neos programming language, enabling text-based data manipulation and processing. Understanding strings is essential for handling textual data in Neos programmes, from user input to data representation.", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "/Hello World/", contentType: LearningDetailsContentType.code, navID: navID),
    ]
    
    lazy var keywordList: [LearningContent] = [
        LearningContent(id: UUID(), content: "Understanding the \"think\" Keyword: A Quick Overview", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "In Neos, the \"think\" keyword acts as an instruction for declaring variables. Programmers can easily construct and initialise variables to hold different kinds of data by utilising \"think\" which makes it possible for data to be handled and stored within Neos programmes in an easy-to-use manner. \"think\" makes it easier to define and manage variables with its simple syntax, which improves the readability and effectiveness of Neos code.", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "think", contentType: LearningDetailsContentType.code, navID: navID),
        
        LearningContent(id: UUID(), content: "Exploring the \"check\" Keyword: An Introduction", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "When constructing conditional statements like if-else const\"check\" keyword in Neos signals the start of a control block. Through the utilisation of \"check\" programmers can proficiently regulate the progression of their Neos programmes, rendering decisions contingent upon predetermined criteria. The \"check\" command simplifies the construction of logical structures with its brief and unambiguous syntax, enabling developers to produce well-organized and effective Neos code.", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "check", contentType: LearningDetailsContentType.code, navID: navID),
        
        LearningContent(id: UUID(), content: "Understanding the \"if\" Keyword: A Brief Overview", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "Within control blocks, the \"if\" keyword in Neos comes before the conditional expression and comes after the \"check\" directive. It is a key element in the implementation of conditional statements, enabling programmers to run particular code blocks in response to predefined conditions. \"if\"'s simple syntax makes it easier to design decision-making structures in Neos programmes, allowing programmers to write logic that adapts dynamically to different situations.", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "if", contentType: LearningDetailsContentType.code, navID: navID),
        
        LearningContent(id: UUID(), content: "Exploring the \"yes\" Keyword: A Quick Overview", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "In Neos, the \"yes\" keyword operates in the context of conditional statements. It comes after the \"if\" directive and before an operator. It acts as a marker for when the condition in the \"if\" statement evaluates to true, starting the execution of the code. Programmers can specify what should happen when certain conditions are met by using \"yes\" which adds flexibility and logic to Neos programmes.", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "yes", contentType: LearningDetailsContentType.code, navID: navID),
        
        LearningContent(id: UUID(), content: "Understanding the \"else\" Keyword: A Concise Explanation", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "When the condition stated in the \"if\" statement evaluates to false, the \"else\" keyword in Neos provides an alternate course of action. This complements the \"if\" statement within conditional blocks. With the use of \"else\" programmers can handle situations in which the main condition is not satisfied, providing complete control flow in Neos programmes. With its ability to execute precise code under many scenarios, this adaptable keyword improves the flexibility and robustness of Neos code.", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "else", contentType: LearningDetailsContentType.code, navID: navID),
        
        LearningContent(id: UUID(), content: "Exploring the \"then\" Keyword: An Overview", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "When a control block, such the \"check\" block started by the \"check\" keyword or the \"else\" block started by the \"else\" keyword, ends in Neos, the \"then\" keyword acts as a signal to indicate it. In order to guarantee organised and legible code, it offers a distinct marker to indicate the end of a conditional expression. With \"then\" programmers may keep code organised and improve the control flow clarity of Neos programmes.", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "then", contentType: LearningDetailsContentType.code, navID: navID),
        
        LearningContent(id: UUID(), content: "Exploring the \"show\" Keyword: A Quick Overview", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "To display or print the value of a variable or expression in Neos, use the \"show\" keyword. This crucial keyword gives you insights into the present state of variables or computations, which makes debugging easier and improves programme readability. Through the use of \"show\" programmers may efficiently diagnose and improve the logic of their Neos code by monitoring programme output and confirming that their code is valid.", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "show", contentType: LearningDetailsContentType.code, navID: navID),
        
        LearningContent(id: UUID(), content: "Understanding the \"update\" Keyword: A Brief Explanation", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "The \"update\" keyword in Neos makes it easier to change the value of a variable, especially if the new value is of the same datatype as the variable. This keyword is essential to dynamic programming because it allows programmers to easily change the contents of variables while the programme is running. Programmers can effectively handle data in their Neos programmes by using \"update\" which guarantees flexibility and adaptability in response to situations or requirements that change.", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "update", contentType: LearningDetailsContentType.code, navID: navID),
    ]
    
    lazy var operatorList: [LearningContent] = [
        LearningContent(id: UUID(), content: "Understanding the \"is\" Operator: A Concise Explanation", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "Programmers can assign values to variables in Neos by using the \"is\" operator, which functions like an assignment operator. This adaptable operator makes it easier to initialise variables with certain values, which improves the code's flexibility and efficiency in Neos. With \"is\" programmers may guarantee accurate data manipulation in their Neos programmes and expedite the variable assignment procedure.", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "is", contentType: LearningDetailsContentType.code, navID: navID),
        
        LearningContent(id: UUID(), content: "Exploring the \"do\" Keyword: A Brief Overview", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "The \"do\" keyword in Neos signals the start of a code block where execution takes place. This flexible operator allows programmers to construct and run sequences of instructions by starting the execution of a set of statements contained within the block. \"do\" developers may manage the flow of their Neos programmes and ensure that code is executed in an efficient and structured manner.", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "do", contentType: LearningDetailsContentType.code, navID: navID),
        
        LearningContent(id: UUID(), content: "Understanding the \"stop\" Keyword: A Quick Explanation", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "The \"stop\" keyword in Neos functions as an instruction to stop a code block's execution. When \"stop\" is included at the end of a block, such as \"check\" block, it indicates that the \"check\" block is ended here.", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "stop", contentType: LearningDetailsContentType.code, navID: navID),
        
        LearningContent(id: UUID(), content: "Exploring the \"with\" Operator: A Brief Overview", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "To change the value of a predefined variable in Neos, use the \"with\" operator and the \"update\" keyword. This operator allows programmers to update a variable's value with a new value in a manner similar to that of an assignment operator. When developers use \"with\" in conjunction with \"update\" they may effectively work with variable contents and guarantee accurate data management in their Neos programmes.", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "with", contentType: LearningDetailsContentType.code, navID: navID),
    ]
    
    lazy var declarationList: [LearningContent] = [
        LearningContent(id: UUID(), content: "Declaring an Integer Variable in Neos: A Quick Example", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "In Neos, to declare an integer variable named \"i\" with an initial value of 10, you would use the following syntax:", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "think int i is 10", contentType: LearningDetailsContentType.run, navID: navID),
        LearningContent(id: UUID(), content: "Here, \"think\" is the variable declaration keyword, \"int\" specifies the datatype as integer, \"i\" is the identifier name for the variable, and \"is\" acts as the assignment operator, assigning the value 10 to the variable \"i\". This statement initializes the integer variable \"i\" with the value of 10.", contentType: .content, navID: navID),
        
        LearningContent(id: UUID(), content: "Declaring a String Variable in Neos: An Example", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "To declare a string variable named \"i\" with the value \"Hello World\" in Neos, you would use the following syntax:", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "think string i is /Hello World/", contentType: LearningDetailsContentType.run, navID: navID),
        LearningContent(id: UUID(), content: "•\t\"think\" serves as the variable declaration keyword.\n•\t\"string\" specifies the datatype as string.\n•\t\"i\" represents the identifier name for the variable.\n•\t\"is\" acts as the assignment operator.\n•\t\"\\Hello World\\\" represents the value assigned to the variable \"i\", enclosed within backslashes to indicate it's a string literal.", contentType: .content, navID: navID),
        
        LearningContent(id: UUID(), content: "Declaring a Float Variable in Neos: An Illustration", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "To declare a float variable named \"x\" with an initial value of 3.14 in Neos, you would utilize the subsequent syntax:", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "think float x is 3.14", contentType: LearningDetailsContentType.run, navID: navID),
        LearningContent(id: UUID(), content: "•\t\"think\" functions as the variable declaration keyword.\n•\t\"float\" indicates the datatype as a floating-point number.\n•\t\"x\" denotes the identifier name for the variable.\n•\t\"is\" serves as the assignment operator.\n•\t\"3.14\" represents the value assigned to the variable \"x\", which is a float value.", contentType: .content, navID: navID),
        
        LearningContent(id: UUID(), content: "Defining a Double Variable in Neos: A Representation", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "To define a double variable named \"value\" with an initial value of 3.14159 in Neos, adhere to this syntax:", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "think double value is 3.14159", contentType: LearningDetailsContentType.run, navID: navID),
        LearningContent(id: UUID(), content: "•\t\"think\" serves as the variable declaration keyword.\n•\t\"double\" specifies the datatype as a double-precision floating-point number.\n•\t\"value\" identifies the variable.\n•\t\"is\" functions as the assignment operator.\n•\t\"3.14159\" represents the value assigned to the variable \"value\", which is a double-precision floating-point value.", contentType: .content, navID: navID),
        
        LearningContent(id: UUID(), content: "Establishing a Boolean Variable in Neos: An Example", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "To create a boolean variable named \"isNeosFun\" with an initial value of true in Neos, employ this syntax:", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "think bool isNeosFun is true", contentType: LearningDetailsContentType.run, navID: navID),
        LearningContent(id: UUID(), content: "•\t\"think\" operates as the variable declaration keyword.\n•\t\"bool\" signifies the datatype as boolean.\n•\t\"isNeosFun\" denotes the variable's identifier.\n•\t\"is\" acts as the assignment operator.\n•\t\"true\" signifies the value assigned to the variable \"isNeosFun\", which is a boolean value.", contentType: .content, navID: navID),
    ]
    
    lazy var practice1List: [LearningContent] = [
        LearningContent(id: UUID(), content: "Practice Exercise: Variable Declaration in Neos", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "Declare the following variables in Neos according to the provided specifications:\n\n1. Declare an integer variable named \"numberOfStudents\" with an initial value of 50.\n\n2. Declare a string variable named \"welcomeMessage\" with an initial value of \"Welcome to Neos Programming!\".\n\n3. Declare a float variable named \"piValue\" with an initial value of 3.14159.\n\n4. Declare a boolean variable named \"isNeosAwesome\" with an initial value of true.\n\n5. Declare a double variable named \"price\" with an initial value of 99.99.\n\nWrite Neos code to perform these variable declarations, making sure to use the appropriate syntax and keywords.\n\nOnce you've completed the exercise, you can verify your solutions to ensure they match the given specifications. Let me know if you need further assistance or if you'd like to discuss your solutions!", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "think int numberOfStudents is 50\n\nthink string welcomeMessage is /Welcome to Neos Programming!/\n\nthink float piValue is 3.14159\n\nthink bool isNeosAwesome is true\n\nthink double price is 99.99", contentType: LearningDetailsContentType.textField, navID: navID),
        LearningContent(id: UUID(), content: "Here are some hints to help you with the practice exercise:\n\n1. For declaring an integer variable, you'll use the \"think\" keyword followed by the datatype \"int\", the variable name \"numberOfStudents\", the assignment operator \"is\", and the initial value \"50\".\n\n2. Similarly, for declaring a string variable, you'll use the datatype \"string\" and enclose the initial value \"Welcome to Neos Programming!\" within backslashes \"\\\".", contentType: LearningDetailsContentType.hint, navID: navID)
    ]
    
    lazy var conditionalList: [LearningContent] = [
        LearningContent(id: UUID(), content: "Implementing a Conditional Check Block Using Integer Values in Neos", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "To demonstrate the usage of a conditional check block in Neos, consider the following example:", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "check if ( 1 > 2 ) is yes do\n* show /Hello/\nelse\n* show /World/\nthen stop", contentType: LearningDetailsContentType.run, navID: navID),
        LearningContent(id: UUID(), content: "Explanation:", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "•\tThe \"check\" keyword initiates a conditional block in Neos.\n•\tThe \"if\" statement checks if the condition \"(1 > 2)\" evaluates to true.\n•\tThe \"is yes\" clause specifies that the condition should be true for the subsequent block to execute.\n•\tThe \"do\" keyword indicates the start of the block to execute if the condition is true.\n•\tWithin the \"if\" block, \"Hello\" is displayed using the \"show\" keyword.\n•\tIf the condition evaluates to false, the \"else\" block is executed.\n•\tWithin the \"if\" block, \"Hello\" is displayed using the \"show\" keyword.\n•\tWithin the \"else\" block, \"World\" is displayed using the show keyword.\n•\tThe \"then stop\" statement is added to halt the execution of the \"else\" block.", contentType: .content, navID: navID),
        
        LearningContent(id: UUID(), content: "Implementing a Conditional Check Block Using Float Values in Neos", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "To demonstrate the usage of a conditional check block with float values in Neos, consider the following example:", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "check if ( 3.14 < 2.718 ) is yes do\n* show /Pi is less than e/\nelse\n* show /Pi is greater than e/\nthen stop", contentType: LearningDetailsContentType.run, navID: navID),
        LearningContent(id: UUID(), content: "Explanation:", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "•\tThe \"check\" keyword initiates a conditional block in Neos.\n•\tThe \"if\" statement checks if the condition \"( 3.14 < 2.718 )\" evaluates to true.\n•\tThe \"is yes\" clause specifies that the condition should be true for the subsequent block to execute.\n•\tThe \"do\" keyword indicates the start of the block to execute if the condition is true.\n•\tWithin the \"if\" block, \"Pi is less than e\" is displayed using the \"show\" keyword.\n•\tIf the condition evaluates to false, the \"else\" block is executed.\n•\tWithin the \"else\" block, \"Pi is greater than e\" is displayed using the \"show\" keyword.\n•\tThe \"then stop\" statement is added to halt the execution of the block.", contentType: .content, navID: navID),
        
        LearningContent(id: UUID(), content: "Implementing a Conditional Check Block Using Double Values in Neos", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "To illustrate the usage of a conditional check block with double values in Neos, consider this example:", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "check if ( 3.14 < 2.718 ) is yes do\n* show /Pi is less than e/\nelse\n* show /Pi is greater than e/\nthen stop", contentType: LearningDetailsContentType.run, navID: navID),
        LearningContent(id: UUID(), content: "Explanation:", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "•\tThe \"check\" keyword initializes a conditional block in Neos.\n•\tThe \"if\" statement evaluates whether the condition \"( 3.14 < 2.718 )\" is true.\n•\tThe \"is yes\" clause specifies that the condition must be true for the subsequent block to execute.\n•\tThe \"do\" keyword marks the start of the block to execute if the condition is true.\n•\tWithin the \"if\" block, \"Pi is less than e\" is displayed using the \"show\" keyword.\n•\tIf the condition evaluates to false, the \"else\" block is executed.\n•\tWithin the \"else\" block, \"Pi is greater than e\" is displayed using the \"show\" keyword.\n•\tThe \"then stop\" statement terminates the execution of the block.", contentType: .content, navID: navID),
        
        LearningContent(id: UUID(), content: "Implementing a Conditional Check Block Using String Values in Neos", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "To demonstrate the usage of a conditional check block with string values in Neos, consider the following example:", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "check if ( /Neos/ == /Programming/ ) is yes do\n* show /Neos is equal to Programming/\nelse\n* show /Neos is not equal to Programming/\nthen stop", contentType: LearningDetailsContentType.run, navID: navID),
        LearningContent(id: UUID(), content: "Explanation:", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "•\tThe \"check\" keyword initiates a conditional block in Neos.\n•\tThe \"if\" statement checks if the condition \"( /Neos/ == /Programming/ )\" evaluates to true.\n•\tThe \"is yes\" clause specifies that the condition should be true for the subsequent block to execute.\n•\tThe \"do\" keyword indicates the start of the block to execute if the condition is true.\n•\tWithin the \"if\" block, \"Neos is equal to Programming\" is displayed using the \"show\" keyword.\n•\tIf the condition evaluates to false, the \"else\" block is executed.\n•\tWithin the \"else\" block, \"Neos is not equal to Programming\" is displayed using the \"show\" keyword.\n•\tThe \"then stop\" statement is added to halt the execution of the block.", contentType: .content, navID: navID),
        
        LearningContent(id: UUID(), content: "Implementing a Conditional Check Block Using Boolean Values in Neos", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "To demonstrate the usage of a conditional check block with boolean values in Neos, consider the following example:", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "think bool isComing is false\nthink bool isGoing is true\n\ncheck if ( isComing == isGoing ) is yes do\n* show /Ok, fine/\nelse\n* show /Ok, let me check/\nthen stop", contentType: LearningDetailsContentType.run, navID: navID),
        LearningContent(id: UUID(), content: "Explanation:", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "•\tThe \"think\" keyword initializes boolean variables \"isComing\" and \"isGoing\" with values false and true, respectively.\n•\tThe \"check\" keyword initiates a conditional block in Neos.\n•\tThe \"if\" statement checks if the condition \"( isComing == isGoing )\" evaluates to true.\n•\tThe \"is yes\" clause specifies that the condition should be true for the subsequent block to execute.\n•\tThe \"do\" keyword indicates the start of the block to execute if the condition is true.\n•\tWithin the \"if\" block, \"Ok, fine\" is displayed using the \"show\" keyword.\n•\tIf the condition evaluates to false, the \"else\" block is executed.\n•\tWithin the \"else\" block, \"Ok, let me check\" is displayed using the \"show\" keyword.\n•\tThe \"then stop\" statement is added to halt the execution of the block.", contentType: .content, navID: navID),
        
        LearningContent(id: UUID(), content: "Implementing a Conditional Check Block Using Boolean Values in Neos", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "To demonstrate the usage of a conditional check block with boolean values in Neos, consider the following example:", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "think bool isGoing is true\n\ncheck if ( isGoing == false ) is yes do\n* show /Not going/\nelse\n* show /Ok, going/\nthen stop", contentType: LearningDetailsContentType.run, navID: navID),
        LearningContent(id: UUID(), content: "Explanation:", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "•\tThe \"think\" keyword initializes a boolean variable \"isGoing\" with the value true.\n•\tThe \"check\" keyword initiates a conditional block in Neos.\n•\tThe \"if\" statement checks if the condition \"( isGoing == false )\" evaluates to true.\n•\tThe \"is yes\" clause specifies that the condition should be true for the subsequent block to execute.\n•\tThe \"do\" keyword indicates the start of the block to execute if the condition is true.\n•\tWithin the \"if\" block, \"Not going\" is displayed using the \"show\" keyword.\n•\tIf the condition evaluates to false, the \"else\" block is executed.\n•\tWithin the \"else\" block, \"Ok, going\" is displayed using the \"show\" keyword.\n•\tThe \"then stop\" statement is added to halt the execution of the block.", contentType: .content, navID: navID),


    ]
    
    lazy var practice2List: [LearningContent] = [
        LearningContent(id: UUID(), content: "Practice Exercise: Conditional Control Statements in Neos", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "Write Neos code to implement the following conditional control statements:\n\n1. Implement a check block that checks if the variable \"isNeosFun\" is true. If true, display \"Neos is fun!\"; otherwise, display \"Neos is not fun!\".\n\n2. Implement another check block that checks if the variable \"age\" is greater than or equal to 18. If true, display \"You are an adult.\"; otherwise, display \"You are a minor.\".\n\n3. Create a check block that verifies if the variable \"isRaining\" is false. If false, display \"It's a sunny day!\"; otherwise, display \"It's raining outside!\".\n\nRemember to use the appropriate syntax and keywords in your Neos code.\n\nOnce you've completed the exercise, you can verify your solutions to ensure they match the given specifications. Let me know if you need further assistance or if you'd like to discuss your solutions!", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "think bool isNeosFun is true\n\ncheck if ( isNeosFun == true ) is yes do\n* show /Neos is fun!/\nelse\n* show /Neos is not fun!/\nthen stop\n\nthink int age is 20\n\ncheck if ( age >= 18 ) is yes do\n* show /You are an adult./\nelse\n* show /You are a minor./\nthen stop\n\nthink bool isRaining is false\n\ncheck if ( isRaining == false ) is yes do\n* show /It is a sunny day!/\nelse\n* show /It is a raining outside!/\nthen stop", contentType: LearningDetailsContentType.textField, navID: navID),
        LearningContent(id: UUID(), content: "Here are some hints to help you with the practice exercise:\n\n1. For implementing a check block, start with the \"check\" keyword followed by the condition you want to check.\n\n2. Use the \"is yes\" clause after the condition to specify the condition to be true.\n\n3. Utilize the \"do\" keyword to indicate the start of the block of code to execute if the condition is true.\n\n4. Inside the block, use the \"show\" keyword followed by the message you want to display.\n\n5. Don't forget to include the \"then stop\" statement at the end of each block to stop further execution.\n\n6. For the else block, simply add the \"else\" keyword followed by the code to execute if the condition is false.", contentType: LearningDetailsContentType.hint, navID: navID)
    ]
    
    lazy var finalTestList: [LearningContent] = [
        // Variable declaration
        LearningContent(id: UUID(), content: "Final Test: Neos Programming Concepts", contentType: .heading, navID: navID),
        LearningContent(id: UUID(), content: "Instructions:\n\nWrite Neos code to demonstrate the following concepts:\n\n1. Declare an integer variable named \"numberOfStudents\" with an initial value of 50.\n\n2. Declare a string variable named \"welcomeMessage\" with an initial value of \"Welcome to Neos Programming!\".\n\n3. Declare a float variable named \"piValue\" with an initial value of 3.14159.\n\n4. Declare a boolean variable named \"isNeosAwesome\" with an initial value of true.\n\n5. Declare a double variable named \"price\" with an initial value of 99.99.\n\n6. Implement a check block that checks if the variable \"isNeosFun\" is true. If true, display \"Neos is fun!\"; otherwise, display \"Neos is not fun!\".\n\n7. Implement another check block that checks if the variable \"age\" is greater than or equal to 18. If true, display \"You are an adult.\"; otherwise, display \"You are a minor.\".\n\n8. Create a check block that verifies if the variable \"isRaining\" is false. If false, display \"It's a sunny day!\"; otherwise, display \"It's raining outside!\".\n\n9. Implement a check block that verifies if numberOfStudents is greater than 25. If true, show \"Teacher will take the class\"; otherwise, show \"The class will cancel\".\n\nRemember to use the appropriate syntax and keywords in your Neos code.\n\nOnce you've completed the test, you can verify your solutions to ensure they match the given specifications. Let me know if you need further assistance or if you'd like to discuss your solutions!", contentType: .content, navID: navID),
        LearningContent(id: UUID(), content: "think int numberOfStudents is 50\n\nthink string welcomeMessage is /Welcome to Neos Programming!/\n\nthink float piValue is 3.14159\n\nthink bool isNeosAwesome is true\nthink bool isNeosfun is true\n\nthink double price is 99.99\n\nthink bool isRaining is false\n\ncheck if ( isNeosFun == true ) is yes do\n* show /Neos is fun!/\nelse\n* show /Neos is not fun!/\nthen stop\n\ncheck if ( isRaining == false ) is yes do\n* show /It is a sunny day!/\nelse\n* show /It is raining outside!/\nthen stop\n\ncheck if ( numberOfStudents > 25 ) is yes do\n* show /Teacher will take the class./\nelse\n* show /The class will cancel./\nthen stop", contentType: LearningDetailsContentType.textField, navID: navID),
        LearningContent(id: UUID(), content: "Here are some hints to help you with the test:\n\n1. For declaring variables, use the \"think\" keyword followed by the datatype and variable name, and then use the \"is\" keyword for assignment.\n\n2. For conditional blocks, start with the \"check\" keyword followed by the condition to check. Use the \"is yes\" clause for true conditions, and the \"else\" keyword for false conditions.\n\n3. Inside conditional blocks, use the \"do\" keyword to start the block of code to execute. Use the \"show\" keyword to display messages.\n\n4. Remember to include the \"then stop\" statement at the end of each block to stop further execution.", contentType: LearningDetailsContentType.hint, navID: navID)
    ]

}
