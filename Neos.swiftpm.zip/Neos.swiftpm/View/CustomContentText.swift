import SwiftUI

struct CustomContentText: View {
    let text: String
    
    var body: some View {
        HStack {
            Text(text)
                .foregroundStyle(.white)
                .font(.system(size: 20, weight: .regular, design: .monospaced))
                .lineSpacing(15)
                .padding(.bottom, 20)
                .tracking(0.5)
            
            Spacer()
            
        }
    }
}
