import SwiftUI

struct LearningView: View{
    
    let learningList = Lists.learningModels
    
    @Binding var currentScreen: LearningScreen
    
//    @State var currentScreen: LearningScreen = .main("")
//        .datatype("datatypes")
    @Binding var nextString: String
    
    var body: some View{
            
        ScrollView {
            
            switch currentScreen {
            case .main(_):
                ForEach(Array(learningList.enumerated()), id: \.1.id) { index, learning in
                    
                    VStack(content: {
                        ExpandableView(
                            thumbnail: ThumbnailView(content: {
                                
                                CardView(learningDetails: learning, index: index, show: false, action: {
                                    
                                    withAnimation(.easeInOut(duration: 0.5), {
                                        nextString = Generator().capitalizeFirstCharacter(learning.navID)
                                        
                                        switch learning.navID {
                                        case "datatypes":
                                            currentScreen = .datatype(Generator().capitalizeFirstCharacter(learning.navID))
                                            break
                                            
                                        case "keywords":
                                            currentScreen = .keyword(Generator().capitalizeFirstCharacter(learning.navID))
                                            break
                                            
                                        case "operators":
                                            currentScreen = .op(Generator().capitalizeFirstCharacter(learning.navID))
                                            break
                                            
                                        case "declarations":
                                            currentScreen = .declaration(Generator().capitalizeFirstCharacter(learning.navID))
                                            break
                                            
                                        case "Practice#1":
                                            currentScreen = .practice1(Generator().capitalizeFirstCharacter(learning.navID))
                                            break
                                            
                                        case "conditional":
                                            currentScreen = .conditional(Generator().capitalizeFirstCharacter(learning.navID))
                                            break
                                            
                                        case "Practice#2":
                                            currentScreen = .practice2(Generator().capitalizeFirstCharacter(learning.navID))
                                            break
                                            
                                        case "finaltest":
                                            currentScreen = .finaltest(Generator().capitalizeFirstCharacter(learning.navID))
                                            break
                                            
                                        default: break
                                        }
                                        
                                    })
                                    
                                    
                                })
                                
                                
                            }), 
                            expanded: ExpandedView(content: {
                                
                                CardView(learningDetails: learning, index: index, show: true, action: {
                                    currentScreen = .datatype(Generator().capitalizeFirstCharacter(learning.navID))
                                })
                                
                            }))
                    })
                    
                }
                .padding(.horizontal, 20)
                .padding(.top, 15)
                
            case .datatype(let navID):
                LearningDetailsView(learningContents: ContentLists(navID: navID).datatypeList)
            case .keyword(let navID):
                LearningDetailsView(learningContents: ContentLists(navID: navID).keywordList)
            case .op(let navID):
                LearningDetailsView(learningContents: ContentLists(navID: navID).operatorList)
            case .declaration(let navID):
                LearningDetailsView(learningContents: ContentLists(navID: navID).declarationList)
            case .practice1(let navID):
                LearningDetailsView(learningContents: ContentLists(navID: navID).practice1List)
            case .conditional(let navID):
                LearningDetailsView(learningContents: ContentLists(navID: navID).conditionalList)
            case .practice2(let navID):
                LearningDetailsView(learningContents: ContentLists(navID: navID).practice2List)
            case .finaltest(let navID):
                LearningDetailsView(learningContents: ContentLists(navID: navID).finalTestList)
            }
            
        }
        .padding(.horizontal, 25)
        .padding(.vertical, 20)
        
    }
}

enum LearningScreen {
    case main(String)
    case datatype(String)
    case keyword(String)
    case op(String)
    case declaration(String)
    case practice1(String)
    case conditional(String)
    case practice2(String)
    case finaltest(String)
}
