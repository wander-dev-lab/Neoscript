import SwiftUI

struct ThumbnailView: View, Identifiable {
    
    var id = UUID()
    @ViewBuilder var content: any View
    
    var body: some View {
        ZStack(content: {
            AnyView(content)
        })
    }
    
}
