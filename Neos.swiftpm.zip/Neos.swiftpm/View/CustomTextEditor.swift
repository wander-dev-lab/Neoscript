import SwiftUI

struct CustomTextEditor: View {
    @State var text: String = ""
    @State var show:Bool = false
    @State var output: String = ""
    @State var error: ErrorModel = ErrorModel( isValid: false, errorMessage: "")
    let learningContent: LearningContent
    
    func trimStrings(list: [String]) -> [String] {
        
        var newList: [String] = []
        
        for line in list {
            
            let trimmedLine = line.trimmingCharacters(in: .whitespacesAndNewlines)
            
            if !trimmedLine.isEmpty {
                newList.append(trimmedLine)
            }
        }
        
        return newList
    }
    
    var body: some View {
        
        CustomRunButton(leadingIcon: "play.fill", title: "Verify & Run", action: {
            
//            print("text", text)
            
            if !text.isEmpty {
                
                withAnimation(.easeInOut(duration: 0.5), {
                    
                    let contentList = trimStrings(list: learningContent.content.components(separatedBy: "\n"))
                    
                    let textList = trimStrings(list: text.components(separatedBy: "\n"))
                    
                    print("contentList", contentList)
                    print("textList", textList)
                    
                    if contentList == textList {
                        var tokens = LexicalAnalyser().analyse(from: text)
                        
                        let (analysisError, conditions) = SyntaxAnalyser().analyse(tokensOfLines: tokens)
                        error = analysisError
                        
                        if error.isValid {
                            error = SemanticAnalyser().analyse(tokensOfLines: tokens, conditions: conditions)
                        }
                        
                        if error.isValid {
                            //                        print()
                            let outputs = Executer().execute(tokens: &tokens, conditions: conditions)
                            //                        print("inner", innerTokens)
                            output = outputs.joined(separator: "\n\n")
                            output = output.trimmingCharacters(in: .whitespacesAndNewlines)
                            show = true
                            print("output", output)
                        }
                        
                        
                        
                    }
                    else {
                        error = ErrorModel( isValid: false, errorMessage: "The answer is not correct")
                        show = false
                    }
                })
                
            }
            
            else {
                error = ErrorModel( isValid: false, errorMessage: "Please Right the proper answer.")
                show = false
            }
        })
        
        VStack(alignment: .leading, spacing: 5) {
            Text("Neos")
                .foregroundStyle(.white)
                .font(.system(size: 30, weight: .medium, design: .monospaced))
                .padding()
            
            TextEditor(text: $text)
                .padding()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .font(.system(size: 20, weight: .medium, design: .monospaced))
                .foregroundColor(.white)
                .disableAutocorrection(true) // Disable autocorrection
                .multilineTextAlignment(.leading)
                .background(Color.gray.opacity(0.01))
                .clipShape(RoundedRectangle(cornerRadius: 20))
                .cornerRadius(20)
        }
        .frame(maxWidth: .infinity)
        .frame(height: 500)
        .background(Color.gray.opacity(0.25))
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .padding(.bottom, show ? 5 : 15)
        .padding(.top, 5)
        if !error.isValid {
            HStack( content: {
                Text(error.errorMessage ?? "")
                    .foregroundStyle(.red)
                    .font(.system(size: 20, weight: .semibold, design: .monospaced))
                    .padding(.vertical, 10)
                Spacer()
            })
        }
        
        if show {
            HStack {
                VStack(alignment: .leading) {
                    Text("Output")
                        .foregroundStyle(.white)
                        .font(.system(size: 25, weight: .regular, design: .monospaced))
                        .padding(.bottom, 20)
                    
                    Text(output)
                        .foregroundStyle(.white)
                        .font(.system(size: 20, weight: .semibold, design: .monospaced))
                }
                .padding(.vertical, 25)
                .padding(.horizontal, 25)
                
                Spacer()
            }
            .frame(maxWidth: .infinity)
            .background(Color.gray.opacity(0.25))
            .clipShape(RoundedRectangle(cornerRadius: 20))
            .padding(.bottom, 20)
        }
    }
}
