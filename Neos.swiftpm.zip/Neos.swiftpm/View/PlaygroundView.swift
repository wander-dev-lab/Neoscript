import SwiftUI

struct PlaygroundView: View{
    
    @State var textEditorText: String = ""
    @State var compiledText: String = ""
    @State var output: String = ""
    @State var afterCompilation: ErrorModel = ErrorModel(isValid: false)
    @State private var isHovering = false
    @State private var isHovered = false
    @State private var isFocused = false
    let compiler = Compilation()
    let lexicalanalyser = LexicalAnalyser()
    let executer = Executer()
    let generator = Generator()
    
    var body: some View{
        VStack {
            GeometryReader { geometry in
                VStack(spacing: 20,content: {
                    HStack(alignment: .top, spacing: 10, content: {
                        
                        VStack(alignment: .leading, spacing:10,content: {
                            
                            Text("Neos")
                                .font(.system(size: 25, weight: .medium, design: .rounded))
                            
                            TextEditor(text: $textEditorText)
                                .padding()
                                .onChange(of: textEditorText) { oldText, newText in
                                    // Perform actions when the text changes
                                    //                                print("newText: \(newText) oldText \(oldText)")
                                    
                                    withAnimation(.easeInOut(duration: 0.3)) {
                                        afterCompilation = compiler.compile(for: textEditorText)
                                        compiledText = afterCompilation.errorMessage ?? "Unknown Error"
                                    }
                                    
                                }
                                .frame(width: .infinity, height: .infinity)
                                .font(.system(size: 20, weight: .medium, design: .monospaced))
                                .disableAutocorrection(true) // Disable autocorrection
                                .multilineTextAlignment(.leading)
                                .background(Color.white.quinary.opacity(0.65))
                                .cornerRadius(20)
                        })
                        
                        if !textEditorText.isEmpty && !afterCompilation.isValid {
                            VStack(alignment: .leading, spacing:10, content: {
                                
                                Text( afterCompilation.isValid ? "Swift" : "Errors")
                                    .font(.system(size: 25, weight: .medium, design: .rounded))
                                
                                TextEditor(text: $compiledText)
                                    .disabled(true)
                                    .padding()
                                    .frame(width: .infinity, height: .infinity)
                                    .font(.system(size: 19, weight: .medium, design: .monospaced))
                                    .disableAutocorrection(true) // Disable autocorrection
                                    .multilineTextAlignment(.leading)
                                    .background(Color.white.quinary.opacity(0.65))
                                    .cornerRadius(20)
                            })
                        }
                        
                        
                        
                    })
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    
                    HStack(spacing:20,content: {
                        
                        Text("Output")
                            .font(.system(size: 30, weight: .medium, design: .default))
                        
                        Spacer()
                        
                        Button(action: {
                            
                            var tokens = lexicalanalyser.analyse(from: textEditorText)
                            
//                            let swiftCodes = 
                            
//                            output = generator.generate(tokens: tokens).joined(separator: "\n")
                            
//                            output = tokensToString(tokens: tokens)
                            
                            let (output2, conditions) = SyntaxAnalyser().analyse(tokensOfLines: tokens)
                            output = output2.errorMessage ?? "Unknown"
                            
                            let outputs = Executer().execute(tokens: &tokens, conditions: conditions)
                            
                            output = outputs.joined(separator: "\n")
                            
                        }, label: {
                            HStack(content: {
                                Image(systemName: "globe")
                                    .foregroundColor(.black)
                                    .font(.system(size: 30))
                                
                                Text("Run")
                                    .foregroundColor(.black)
                                    .font(.system(size: 20, weight: .semibold))
                                
                            })
                            
                            .frame(width: 120, height: 50)
                            .background(Color.white)
                            .contentShape(Rectangle())
                            .cornerRadius(20)

                        })
                    })
                    
                    VStack(content: {
                        ScrollView {
                            Text(output)
                                .font(.system(size: 20, weight: .medium, design: .serif))
                        }
                            
                    })
                    .padding()
                    .frame(width: geometry.size.width, height: geometry.size.height/5, alignment: .topLeading)
                    .background(Color.white.quinary.opacity(0.65))
                    .cornerRadius(20)

                })
            }
        }
        .padding()
        
        
    }
    
    
    func tokensToString(tokens: [[Token]]) -> String {
        var result = ""
        
        for line in tokens {
            for token in line {
                result += "\(token.value): \(token.type)"
                // Add a space between tokens
                result += " "
            }
            // Add a newline between lines
            result += "\n"
        }
        
        return result
    }
}
