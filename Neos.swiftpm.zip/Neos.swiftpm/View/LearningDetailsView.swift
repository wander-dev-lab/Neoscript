import SwiftUI

struct LearningDetailsView: View {
    
    let learningContents: [LearningContent]
    @State var heading: Int = 0
    @State var textEditorText: String = ""
    @State var show: Bool = false
    @State var code: String = ""
    
    var body: some View {
        
        ScrollView {
            
            ForEach(learningContents, id: \.id) { learningContent in 
                
                switch learningContent.contentType {
                case .textField:
                    VStack(alignment: .trailing, content: {
                        CustomTextEditor( learningContent: learningContent)
                    })
                    .onAppear(perform: {
                        code = learningContent.content
                    })
                    
                case .hint:
                    VStack {
                        
                        HStack {
                            HeadlineView(content: "Hints")
                            Spacer()
                            Button(action: {
                                withAnimation(.easeInOut(duration: 0.5), {
                                    show.toggle()
                                })
                            }, label: {
                                Image(systemName: show ? "arrow.up" : "arrow.down")
                                    .foregroundStyle(.black)
                                    .font(.system(size: 20, weight: .semibold))
                                    .frame(width: 40, height: 40) // Set width and height
                                    .background(Color.white)
                                    .clipShape(Circle()) // Clip to a circle shape
                            })
                        }
                        
                        if show {
                            
                            Text(learningContent.content + "\n\n" + "Answer Code:\n" + code)
                                .foregroundStyle(.white)
                                .font(.system(size: 20, weight: .regular, design: .monospaced))
                                .lineSpacing(15)
                                .padding(.bottom, 20)
                                .tracking(0.5)
                            
                        }
                        
                    }

                    
                case .code:
                    // Handle code content
                    HStack(content: {
                        VStack(alignment: .leading, content: {
                            Text("Neos")
                                .foregroundStyle(.white)
                                .font(.system(size: 30, weight: .medium, design: .monospaced))
                                .padding(.bottom, 20)
                            
                            Text(learningContent.content)
                                .foregroundStyle(.yellow)
                                .font(.system(size: 25, weight: .medium, design: .monospaced))
                        })
                        .padding(.vertical, 25)
                        .padding(.horizontal, 25)
                        
                        Spacer()
                    })
                    .frame(maxWidth: .infinity)
                    .background(.gray.opacity(0.25))
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .padding(.bottom, 20)
                    
                case .run:
                    // Handle run content
                    CustomRunView(learningContent: learningContent)
//                    VStack(alignment: .trailing, content: {
//                        CustomRunButton(leadingIcon: "play.fill", title: "Run", action: {})
//                        
//                        HStack(content: {
//                            VStack(alignment: .leading, content: {
//                                Text("Neos")
//                                    .foregroundStyle(.white)
//                                    .font(.system(size: 30, weight: .medium, design: .monospaced))
//                                    .padding(.bottom, 20)
//                                
//                                CustomTextView(text: learningContent.content)
//                                
//                            })
//                            .padding(.vertical, 25)
//                            .padding(.horizontal, 25)
//                            
//                            Spacer()
//                        })
//                        .frame(maxWidth: .infinity)
//                        .background(.gray.opacity(0.25))
//                        .clipShape(RoundedRectangle(cornerRadius: 20))
//                        .padding(.bottom, 5)
//                        .padding(.top, 5)
//                        
//                        HStack(content: {
//                            VStack(alignment: .leading, content: {
//                                Text("Output")
//                                    .foregroundStyle(.white)
//                                    .font(.system(size: 25, weight: .regular, design: .monospaced))
//                                    .padding(.bottom, 20)
//                                
//                                Text(learningContent.content)
//                                    .foregroundStyle(.white)
//                                    .font(.system(size: 20, weight: .light, design: .monospaced))
//                                
//                            })
//                            .padding(.vertical, 25)
//                            .padding(.horizontal, 25)
//                            
//                            Spacer()
//                        })
//                        .frame(maxWidth: .infinity)
//                        .background(.gray.opacity(0.25))
//                        .clipShape(RoundedRectangle(cornerRadius: 20))
//                        .padding(.bottom, 20)
//                    })
                case .content:
                    // Handle generic content
                    CustomContentText(text: learningContent.content)
                    
                case .heading:
                    // Handle heading content
                    HeadlineView(content: learningContent.content)
                }
                
            }
            
        }
        .padding(.horizontal, 30)
        .padding(.vertical, 20)
        
    }
    
}
