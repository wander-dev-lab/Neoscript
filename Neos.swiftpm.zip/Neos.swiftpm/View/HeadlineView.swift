import SwiftUI

struct HeadlineView: View {
    
    let content: String
//    @State private var heading: Int = 0
    
    var body: some View {
        HStack(alignment: .top, content: {
//            Text("\(heading).")
//                .foregroundStyle(.white)
//                .font(.system(size: 30, weight: .semibold, design: .monospaced))
//                .padding(.bottom, 20)
            
            Text("\(content):")
                .foregroundStyle(.white)
                .font(.system(size: 30, weight: .semibold, design: .monospaced))
                .padding(.bottom, 20)
                .lineSpacing(10.0)
                .tracking(1.5)
            
            Spacer()
        })
//        .onAppear {
//            // Increment heading by 1 each time the view appears
//            heading += 1
//        }
    }
}
