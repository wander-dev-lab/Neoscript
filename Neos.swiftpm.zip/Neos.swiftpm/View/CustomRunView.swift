import SwiftUI

struct CustomRunView: View {
//    let title: String
//    let action: () -> Void
    let learningContent: LearningContent
    @State var show: Bool = false
    @State var output: String = ""
    
    var body: some View {
        VStack(alignment: .trailing, spacing: 10) {
            CustomRunButton(leadingIcon: "play.fill", title: "Run", action: {
                
                withAnimation(.easeInOut(duration: 0.5), {
                    
                    var tokens = LexicalAnalyser().analyse(from: learningContent.content)
                    
                    var (analysisError, conditions) = SyntaxAnalyser().analyse(tokensOfLines: tokens)
                    
                    if analysisError.isValid {
                        analysisError = SemanticAnalyser().analyse(tokensOfLines: tokens, conditions: conditions)
                    }
                    
                    if analysisError.isValid {
                        //                        print()
                        let outputs = Executer().execute(tokens: &tokens, conditions: conditions)
                        //                        print("inner", innerTokens)
                        output = outputs.joined(separator: "\n\n")
                        output = output.trimmingCharacters(in: .whitespacesAndNewlines)
                        show = true
                        print("output", output)
                    }
                    
                })
                
            })
            
            HStack {
                
                HStack(content: {
                    VStack(alignment: .leading) {
                        Text("Neos")
                            .foregroundColor(.white)
                            .font(.system(size: 30, weight: .medium, design: .monospaced))
                            .padding(.bottom, 20)
                        
                        CustomTextView(text: learningContent.content)
                    }
                    
                    
                    Spacer()
                })
                .padding(25)
                .frame(maxWidth: .infinity)
                .background(Color.gray.opacity(0.25))
                .clipShape(RoundedRectangle(cornerRadius: 20))
                .padding(.bottom, show ? 5 : 20)
                .padding(.top, 5)
                
                Spacer()
                
            }
            if show {
                HStack {
                    HStack(content: {
                        VStack(alignment: .leading) {
                            Text("Output")
                                .foregroundColor(.white)
                                .font(.system(size: 25, weight: .regular, design: .monospaced))
                                .padding(.bottom, 20)
                            
                            // Text view for output
                            Text(output)
                                .foregroundColor(.white)
                                .font(.system(size: 20, weight: .light, design: .monospaced))
                        }
                        
                        Spacer()
                    })
                    .padding(25)
                    .frame(maxWidth: .infinity)
                    .background(Color.gray.opacity(0.25))
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .padding(.bottom, 20)
                    
                    //                Spacer()
                }
            }
        }
    }
}
