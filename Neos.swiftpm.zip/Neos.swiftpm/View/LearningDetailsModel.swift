import Foundation
import SwiftData

enum LearningDetailsContentType: String, Codable, Identifiable, CaseIterable {
    case code
    case run
    case content
    case heading
    case textField
    case hint

    var id: String { self.rawValue }
}

@Model
class LearningContent {
    var id: UUID
    var content: String
    var contentType: LearningDetailsContentType
    var navID: String
    
    init(
        id: UUID,
        content: String,
        contentType: LearningDetailsContentType,
        navID: String
    ) {
        self.id = id
        self.content = content
        self.contentType = contentType
        self.navID = navID
    }
}
