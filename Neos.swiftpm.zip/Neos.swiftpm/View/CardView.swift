import SwiftUI

struct CardView: View {
    
    let learningDetails: LearningModel
    let index: Int
    let show: Bool
    var action: () -> Void
    
    var body: some View {
        HStack(alignment: show ? .top : .center,content: {
            
            Text("\(String(index+1)).")
                .font(.system(size: 25, weight: .semibold, design: .monospaced))
                .foregroundColor(.black)
                .frame(alignment: .topLeading)
            
            VStack(alignment:.leading,content: {
                Text(learningDetails.heading)
                    .foregroundColor(.black)
                    .font(.system(size: 22, weight: .semibold, design: .monospaced))
                
                if show {
                    Text(learningDetails.shortDescription)
                        .foregroundColor(.black)
                        .font(.system(size: 20, weight: .medium, design: .monospaced))
                        .padding(.top, 6)
                }
            })
            
            Spacer()
            
            VStack(alignment: .trailing, content: {
                Button(action: action, label: {
                    
                    ZStack(content: {
                        Circle()
                            .foregroundColor(.black)
                            .frame(width: 55, height: 55)
                            .padding(.horizontal, 10)
                        
                        Image(systemName: "arrow.right")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 20, height: 15) 
                            .foregroundColor(.white)
                            .font(.system(size: 25, weight: .bold, design: .monospaced))
                            .padding()
                    })
                    
                })
            })
            
        })
        .padding()
//        .frame(height: 65)
        .background(Color.white)
        .cornerRadius(20)
        .padding(.bottom, 10)
    }
}

//struct CardView_Preview: PreviewProvider {
//    static let 
//}
