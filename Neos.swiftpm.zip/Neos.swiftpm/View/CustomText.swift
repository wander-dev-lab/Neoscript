import SwiftUI

struct CustomTextView: View {
    let text: String
    
    var body: some View {
        
        
        if text.contains("\n"){
            return Text(text)
                .foregroundStyle(.yellow)
                .font(.system(size: 25, weight: .medium, design: .monospaced))
        }
        else {
            let words = text.components(separatedBy: " ")
            return HStack(spacing: 0) {
                ForEach(words.indices) { index in
                    let word = words[index]
                    Text(word)
                        .foregroundColor(self.color(for: word))
                        .font(.system(size: 25, weight: .semibold, design: .monospaced))
                    if index < words.count - 1 { // Add space after every word except the last one
                        Text("  ")
                    }
                }

            }
        }
    }
    
    // Accessible from outside the view
    func color(for word: String) -> Color {
        if Lists.keywordList.contains(word) {
            return .pink
        }
        else if Lists.datatypeList.contains(word) {
            return .mint
        } 
        else if Lists.operatorList.contains(word) {
            return .green
        }
        else if word.contains("/") || Int(word) != nil || Float(word) != nil || Double(word) != nil || Bool(word) != nil {
            return .cyan
        }
        else {
            return .yellow
        }
    }
}
