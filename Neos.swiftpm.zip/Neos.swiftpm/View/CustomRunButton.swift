import SwiftUI

struct CustomRunButton: View {
    
    var leadingIcon: String
    var title: String
    var action: () -> Void
    
    var body: some View {
        Button(action: action, label: {
            HStack {
                Image(systemName: leadingIcon)
                    .foregroundColor(.black)
                    .font(.system(size: 30))
                    .padding(.horizontal, 5)
//                    .padding(.leading, 10)
                
                Text(title)
                    .foregroundColor(.black)
                    .font(.system(size: 25, weight: .semibold))
                
            }
            .padding(.vertical, 15)
            .padding(.horizontal, 20)
//            .frame(maxWidth: 120)
            .background(Color.white)
            .cornerRadius(20)
        })
    }
}
