import SwiftUI

struct ExpandableView: View {
    
    @Namespace private var namespace
    @State private var show = false
    
    var thumbnail: ThumbnailView
    var expanded: ExpandedView
    
    var body: some View {
        
        ZStack {
            
            if !show {
                thumbnailView()
            }
            else {
                expandedView()
            }
            
        }
        .onTapGesture(perform: {
//            if !show {
                withAnimation(.easeInOut(duration: 0.5)) {
                    show.toggle()
                }
//            }
        })
        
    }
    
    @ViewBuilder
    private func thumbnailView() -> some View {
        
        ZStack {
            thumbnail
                .matchedGeometryEffect(id: "view", in: namespace)
        }
        
        .mask {
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .matchedGeometryEffect(id: "mask", in: namespace)
        }
        
    }
    
    @ViewBuilder
    private func expandedView() -> some View {
        
        ZStack {
            expanded
                .matchedGeometryEffect(id: "view", in: namespace)
//                .background(
//                    Color.green
//                        .matchedGeometryEffect(id: "background", in: namespace))
                .mask {
                    RoundedRectangle(cornerRadius: 20, style: .continuous)
                        .matchedGeometryEffect(id: "mask", in: namespace)
                }
            
//            Button(action: {
//                withAnimation(.spring(response: 0.6, dampingFraction: 0.8)) {
//                    show.toggle()
//                }
//            }, label: {
//                Image(systemName: "xmark")
//                    .foregroundColor(.white)
//            })
//            .padding()
//            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
//            .matchedGeometryEffect(id: "mask", in: namespace)
        }
                
                
    }
}
