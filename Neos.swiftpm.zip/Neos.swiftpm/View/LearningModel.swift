import Foundation

struct LearningModel: Identifiable, Hashable {
    let id: UUID
    let heading: String
    let shortDescription: String
    let navID: String
}
