import SwiftUI

struct AboutView: View{
    
    @State var title: String = "Introduction:\nWelcome to Neos, a revolutionary interpreted programming language designed to break down the barriers to entry for aspiring coders. Developed with Swift, Neos is tailored for individuals with no prior programming experience, offering a straightforward and intuitive approach to learning the fundamentals of coding. Whether you're a student, hobbyist, or professional looking to expand your skill set, Neos provides a user-friendly platform to explore the world of programming.\n\nWhat is Neos?\nNeos stands out for its simplicity and accessibility. It adopts a unique approach by utilizing a simple English-style syntax, making it easy for beginners to grasp programming concepts without getting bogged down by complex terminology. With Neos, anyone can quickly understand how programming languages work and start writing code with confidence.\n\nKey Features:\n1.\tIntuitive Syntax: Neos features a straightforward syntax reminiscent of everyday English, eliminating the intimidation factor often associated with traditional programming languages.\n2.\tComprehensive Learning Resources: Our platform provides ample learning resources, including tutorials, documentation, and interactive exercises, to support users at every step of their coding journey.\n3.\tMulti-Platform Support: Neos is compatible with a wide range of platforms, including iPhone, ensuring seamless accessibility for users across different devices and operating systems.\n4.\tContinuous Development: While Neos is still in heavy development, our team is committed to refining and expanding its capabilities to enhance the learning experience for our users.\n\nWho Can Benefit from Neos?\nNeos is ideal for beginners who are curious about programming but find traditional languages daunting. Whether you're a student exploring coding for the first time, a hobbyist looking to embark on a new challenge, or a professional seeking to broaden your skill set, Neos offers a welcoming environment for individuals of all backgrounds and skill levels.\n\nNeos is still under heavy development, with the primary goal of supporting all the essential features of a robust programming language. Our dedicated team is continuously working on expanding Neos' capabilities to encompass a wide range of functionalities, ensuring that users have access to the tools they need to tackle diverse programming tasks. While in this developmental phase, users can expect regular updates and improvements as we strive to make Neos the ultimate platform for learning and mastering programming concepts.\n\nWith Neos, you can rest assured that you're not just learning a simplified version of programming but rather gaining exposure to the full spectrum of features and functionalities found in traditional languages. Whether you're interested in data structures, algorithms, or object-oriented programming, Neos aims to equip you with the knowledge and skills needed to succeed in the ever-evolving world of software development."
    @State var animateTitle: String = ""
    @State var indexValue = 0
    @State var timeInterval: TimeInterval = 0.009
    @State private var scrollProxy: ScrollViewProxy? = nil
    
    var body: some View{
        
        VStack(content: {

            
            Text("Welcome to Neos!")
                .padding()
                .lineSpacing(20)
                .tracking(1.0)
                .font(.system(size: 35, weight: .bold, design: .monospaced))
                                .frame(maxWidth: .infinity, alignment: .topLeading)
                .padding(.horizontal, 40) // Adjust horizontal padding as needed
                .padding(.top, 50) // Adjust top padding as needed
                .foregroundColor(.white)
            
            ScrollViewReader { proxy in
                ScrollView {
                    Text(animateTitle)
                        .padding()
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                        .padding(.horizontal, 40) // Adjust horizontal padding as needed
                        .padding(.top, 1) // Adjust top padding as needed
                        .foregroundColor(.white)
                        .onAppear {
                            startAnimation()
                            scrollProxy = proxy
                        }
                        .onChange(of: animateTitle) { _oldState, newState in
                            withAnimation {
                                proxy.scrollTo(indexValue, anchor: .bottom) // Scroll to the end when text changes
                            }
                        }
                        .font(.system(size: 22, weight: .medium, design: .monospaced))
                        .tracking(1)
                        .lineSpacing(18.0)
                }
            }
            .padding(.bottom, 20)
            
            Spacer()
        })

    }

    
    func startAnimation() {
        Timer.scheduledTimer(withTimeInterval: timeInterval, repeats: true) {timer in 
            if indexValue < title.count {
                animateTitle += String(title[title.index(title.startIndex, offsetBy: indexValue)])
                
                indexValue += 1
                
                
            }
            else {
                timer.invalidate()
            }
        }
    }
    
    func scrollToBottom() {
        withAnimation {
            scrollProxy?.scrollTo(indexValue, anchor: .bottom)
        }
    }
}
