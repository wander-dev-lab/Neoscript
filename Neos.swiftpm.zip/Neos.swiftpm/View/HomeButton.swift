import SwiftUI

struct HomeButton: View{
    
    var leadingIcon: String
    var title: String
    var action: () -> Void
    
    var body: some View
    {
        Button(action: action, label: {
            HStack(content: {
                Image(systemName: leadingIcon)
                    .foregroundColor(.black)
                    .font(.system(size: 40))
                    .padding(.horizontal, 15)
                    .padding(.leading, 10)
                
                Text(title)
                    .foregroundColor(.black)
                    .font(.system(size: 30, weight: .semibold))
                
                Spacer()
                
                ZStack(content: {
                    Circle()
                        .foregroundColor(.black)
                        .frame(width: 70, height: 70)
                        .padding(.horizontal, 10)
                    
                    Image(systemName: "arrow.right")
                        .resizable() // Make the image resizable
                        .aspectRatio(contentMode: .fit) // Maintain aspect ratio
                        .frame(width: 25, height: 25) // Set the width and height
                        .foregroundColor(.white) // Set the image color
                    
                })
                
            })
            .padding(.vertical, 15)
            .frame(width: 500)
            .background(Color.white)
            .cornerRadius(20)
        })
    }
}
