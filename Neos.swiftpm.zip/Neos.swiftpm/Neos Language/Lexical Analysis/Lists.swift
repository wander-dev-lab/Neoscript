import Foundation

struct Lists {
    static let keywordList = ["think", "check", "if", "yes", "else", "then", "update", "show"]
    
    static let datatypeList = ["int", "string", "float", "double", "bool"]
    
    static let operatorList = ["is", "do", "stop", "with"]
    
    static let reservedKeywordList = ["associatedtype", "class", "deinit", "enum", "extension", "fileprivate", "func", "import", "init", "inout", "internal", "let", "open", "operator", "private", "protocol", "public", "static", "struct", "subscript", "typealias", "var", "break", "case", "continue", "default", "defer", "do", "else", "fallthrough", "for", "guard", "if", "in", "repeat", "return", "switch", "where", "while", "as", "Any", "catch", "false", "is", "nil", "rethrows", "super", "self", "Self", "throw", "throws", "true", "try"]
    
    static let reservedAttributeList = ["@IBAction", "@IBDesignable", "@IBInspectable", "@IBOutlet", "@discardableResult", "@convention", "@escaping", "@autoclosure", "@noescape", "@NSApplicationMain", "@objc", "@discardableResult", "@noreturn", "@testable", "@UIApplicationMain", "@available", "@warn_unqualified_access", "@inline", "@nonobjc", "@objcMembers", "@objc", "@NSCopying", "@NSManaged", "@IBOutlet", "@GKInspectable", "@escaping", "@autoclosure", "@IBInspectable", "@NSManaged", "@IBAction", "@IBDesignable", "@IBInspectable", "@NSCopying", "@NSManaged", "@objc", "@objcMembers", "@convention", "@discardableResult", "@inlinable", "@main"]
    
    static let learningModels: [LearningModel] = [
        LearningModel(id: UUID(), heading: "Datatypes in Neos Language", shortDescription: "Take a tour of the wide range of datatypes that Neos supports. Discover the many functions and representations of these basic data structures. This article demonstrates the range of Neos datatypes, from strings to integers. Discover the representation of each datatype and discover how to use it to your advantage while creating Neos programmes.", navID: "datatypes"),
        
        LearningModel(id: UUID(), heading: "Keywords in Neos Language", shortDescription: "Take a tour of the world of Neos language keywords. Discover the wide range of terms that make up Neos programming's foundation. This page provides how may types of keywords are used in Neos. Discover how to weave the complex web of Neos keywords to influence the logic and actions of your Neos code by getting lost in them, from control flow statements to variable declarations.", navID: "keywords"),
        
        LearningModel(id: UUID(), heading: "Operators in Neos Language", shortDescription: "Take a tour into the world of Neos language operators. Discover the wide range of operators that enable Neos programmers to carry out a vast array of tasks. This article provides a thorough introduction to the arithmetic, comparison, logical, and assignment operators, illuminating their purposes and real-world uses in Neos applications. This short but insightful tutorial gives you the knowledge you need to fully utilise operators in Neos programming, regardless of your level of experience as a developer or how excited you are to learn.", navID: "operators"),
        
        LearningModel(id: UUID(), heading: "Declare Variables", shortDescription: "Take a guided tour through the Neos programming language's variable declarations. Explore the fundamental ideas behind declaring variables in Neos programmes. The subtleties of variable assignments, their data types, and their importance in forming the logic of your Neos code are explained in this article.", navID: "declarations"),
        
        LearningModel(id: UUID(), heading: "Practice #1", shortDescription: "Start a practical adventure with Neos programming's variable declaration exercise. As you work through activities meant to strengthen your grasp of basic concepts, you'll be able to declare variables of different forms of data. This practice session provides a thorough examination of variable assignments and their importance in forming the logic of your Neos code. Take up some practice now to improve your Neos coding skills.", navID: "Practice#1"),
        
        LearningModel(id: UUID(), heading: "Conditional Control Statement", shortDescription: "Take a tour through the Neos programming language's conditional control statements. Discover the subtleties of the decision-making frameworks that enable Neos programmers to regulate programme flow in response to predetermined criteria. The usefulness and real-world uses of conditional expressions, including if-else, in modifying Neos programmes' behaviour are explained in this article.", navID: "conditional"),
        
        LearningModel(id: UUID(), heading: "Practice #2", shortDescription: "Take an interactive tour through the Neos programming language's conditional control statements. Gain a deeper comprehension of decision-making structures by engaging in activities designed to strengthen your ability to use if-else statements. This practice session will help you improve your ability to control programme flow by immersing you in settings where you will create reasoning based on certain conditions. Increase your proficiency with conditional logic in Neos code by beginning to practise.", navID: "Practice#2"),
        
        LearningModel(id: UUID(), heading: "Final Test", shortDescription: "Take a guided tour through the Neos programming language's variable declarations. Explore the fundamental ideas behind declaring variables in Neos programmes. The subtleties of variable assignments, their data types, and their importance in forming the logic of your Neos code are explained in this article.", navID: "finaltest"),
    ]
}
