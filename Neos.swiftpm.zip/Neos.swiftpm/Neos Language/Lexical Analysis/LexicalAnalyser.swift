import Foundation

class LexicalAnalyser {
    
    func parseStringFor(input: String) -> (conditions: String, yesBlock: String, elseBlock: String, remaining: String) {
        var conditions = ""
        var yesBlock = ""
        var elseBlock = ""
        var isYesBlock = false
        var isElseBlock = false
        var remaining = input
        
        // Split the input string by newline
        let lines = input.components(separatedBy: .newlines)
        
        // Iterate through the lines
        for line in lines {
            let components = line.components(separatedBy: .whitespaces)
            
            // Iterate through the components
            var index = 0
            while index < components.count {
                let component = components[index]
                
                if component == "then" && index + 1 < components.count && components[index + 1] == "stop" {
                    // Found "then stop", stop the process
                    break
                }
                
                if component == "if" {
                    // Found "if", start collecting conditions
                    conditions = ""
                    while index + 1 < components.count && components[index + 1] != "is" {
                        conditions += components[index + 1] + " "
                        index += 1
                    }
                } else if component == "is" && index + 2 < components.count && components[index + 1] == "yes" {
                    // Found "is yes", start collecting the yes block
                    isYesBlock = true
                    isElseBlock = false
                    index += 3 // Skip "is yes"
                    continue
                } else if component == "else" {
                    // Found "else", start collecting the else block
                    isYesBlock = false
                    isElseBlock = true
                    index += 1 // Skip "else"
                    continue
                } else if component == "then" {
                    // Found "then", stop collecting blocks
                    break
                }
                
                // Collect lines of the yes block
                if isYesBlock {
                    yesBlock += line + "\n"
                    break
                } else if isElseBlock {
                    elseBlock += line + "\n"
                    break
                }
                
                index += 1
            }
        }
        
        // Remove collected parts from remaining
        if !conditions.isEmpty {
            remaining = remaining.replacingOccurrences(of: conditions, with: "")
        }
        if !yesBlock.isEmpty {
            remaining = remaining.replacingOccurrences(of: yesBlock, with: "")
        }
        if !elseBlock.isEmpty {
            remaining = remaining.replacingOccurrences(of: elseBlock, with: "")
        }
        
        // Concatenate remaining string into a single line
        remaining = remaining.replacingOccurrences(of: "\n", with: " ").trimmingCharacters(in: .whitespacesAndNewlines)
        
        // Remove extra spaces
        remaining = remaining.replacingOccurrences(of: "  ", with: " ")
        
        return (conditions.trimmingCharacters(in: .whitespaces), yesBlock.trimmingCharacters(in: .whitespacesAndNewlines), elseBlock.trimmingCharacters(in: .whitespacesAndNewlines), remaining)
    }
    
    func separateAndCleanWords(from input: String) -> [String] {
        
        let words = input.components(separatedBy: .whitespaces)
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
        
        return words
    }
    
    func separateAndCleanWordsForLines(from text: String) -> [[String]] {
        let lines = text.components(separatedBy: .newlines)
        let cleanedLines = lines.map { separateAndCleanWords(from: $0) }
        return cleanedLines
    }
    
    func determineTokenType(for word: String) -> TokenType? {
        // Check if the word is a keyword
        
        if word.isEmpty{
            return nil
        }
        
        //        print(word)
        if Lists.keywordList.contains(word) {
            return .keyword
        }
        
        // Check if the word is a data type
        else if Lists.datatypeList.contains(word) {
            return .datatype
        }
        
        // Check if the word is an operator
        else if Lists.operatorList.contains(word) {
            return .op
        }
        
        // Check if the word is a variable name
        let firstCharacter = word.first ?? Character("")
        if Bool(word) == nil {
            if (firstCharacter.isLowercase || firstCharacter == "_") {
                // Check if the word contains only alphanumeric characters or underscores
                let isValidVariableName = containsOnlyAlphabets(word) 
                if isValidVariableName {
                    return .identifier
                }
            }
        }
        
        return checkForConstant(for: word)
    }
    
    func containsOnlyAlphabets(_ word: String) -> Bool {
        return word.allSatisfy { $0.isLetter }
    }
    
    func checkForConstant(for word: String) -> TokenType? {
        if Int(word) != nil {
            return .constant
        }
        
        // Check if the word is a float
        if Float(word) != nil {
            return .constant
        }
        
        
        
        // Check if the word is a double value
        if let _ = Double(word) {
            return .constant
        }
        
        // Check if the word is a string literal
        if SemanticAnalyser().containsStringValue(word) {
//            print(word)
            return .constant
        }
        
        // Check if the word is a boolean value
        if word == "true" || word == "false" {
            return .constant
        }
        
        return nil
    }
    
    func convertWordsToTokens(_ words: [String]) -> [Token] {
        var tokens: [Token] = []
        for word in words {
            if let tokenType = determineTokenType(for: word) {
                tokens.append(Token(value: word, type: tokenType))
            }
        }
        
        return tokens
    }
    
    func convertToNestedStringArray( line: String) -> [String] {
        var currentWords: [String] = []
            
            var insideQuotes = false
            var currentQuotedString = ""
            
            for char in line {
                if char == "/" {
                    insideQuotes.toggle()
                    
                    // If we are exiting the quoted string, add the collected string
                    if !insideQuotes {
                        currentWords.append(currentQuotedString)
                        currentQuotedString = ""
                    }
                } else if char == " " && !insideQuotes {
                    // If we are not inside quotes, add the collected word
                    if !currentQuotedString.isEmpty {
                        currentWords.append(currentQuotedString)
                        currentQuotedString = ""
                    }
                } else {
                    // Add the character to the current quoted string
                    currentQuotedString.append(char)
                }
            }
            
            // Append any remaining words or quoted strings
            if !currentQuotedString.isEmpty {
                currentWords.append(currentQuotedString)
            }
        
        return currentWords
    }
    
    func separateLinesWithCheckThenStop(from input: String) -> [String] {
        var result: [String] = []
        var currentSection: [String] = []
        let lines = input.components(separatedBy: "\n")
        
        for line in lines {
            if line.hasPrefix("think") {
                // Append "think" line as a separate element
                result.append(line)
            }
            else if line.hasPrefix("update") {
                // Append "update" line as a separate element
                result.append(line)
            }
            else if line.hasPrefix("show") {
                // Append "show" line as a separate element
                result.append(line)
            }
            else if line.hasPrefix("check") {
                // Start a new section from "check" line
                currentSection.append(line)
            } else if !currentSection.isEmpty {
                if line.hasPrefix("then") || line.hasPrefix("stop") {
                    currentSection.append(line)
                    // End of section, append the collected lines as a single element
                    result.append(currentSection.joined(separator: "\n"))
                    currentSection.removeAll()
                } else {
                    // Add line to the current section
                    currentSection.append(line)
                }
            }
        }
        
        return result
    }
    
    func stringToTokensForCheck(remaining: String, conditions: String, yesBlock: String, elseBlock: String) -> [Token] {
        
        var tokens: [Token] = []
        
        var words: [String] = remaining.components(separatedBy: .whitespaces)
        
        for _ in words {
            
            if let i = words.firstIndex(of: "is"), !words.contains(conditions) {
                words.insert(conditions, at: i)
            }

            
            if let i = words.firstIndex(of: "else"), !words.contains(yesBlock) {
                words.insert(yesBlock, at: i)
            }

            
            if let i = words.firstIndex(of: "then"), !words.contains(elseBlock) {
                words.insert(elseBlock, at: i)
            }

            
        }
        
        for word in words {
            
            if Lists.operatorList.contains(word) {
                
                tokens.append(Token(value: word, type: .op))
                
            }
            
            if Lists.keywordList.contains(word) {
                
                tokens.append(Token(value: word, type: .keyword))
                
            }
            
            if word == conditions {
                
                tokens.append(Token(value: word, type: .condition))
                
            }
            
            if word == yesBlock {
                
                tokens.append(Token(value: word, type: .yesBlock))
                
            }
            
            if word == elseBlock {
                
                tokens.append(Token(value: word, type: .elseBlock))
                
            }
            
        }
        
        return tokens
        
    }
    
    func analyse(from input: String) -> [[Token]] {
        
        var tokensForLines: [[Token]] = []
        
        let lineFromLines = separateLinesWithCheckThenStop(from: input)
        
        print("lineFromLines", lineFromLines)
        
        for line in lineFromLines {
            
            if line.hasPrefix("think") {
                
                let words = convertToNestedStringArray(line: line)
                let tokens = convertWordsToTokens(words)
                tokensForLines.append(tokens)
                print("fromwords" , words)

            }
            
            if line.hasPrefix("update") {
                
                let words = convertToNestedStringArray(line: line)
                let tokens = convertWordsToTokens(words)
                tokensForLines.append(tokens)
                
            }
            
            if line.hasPrefix("show") {
                
                let words = convertToNestedStringArray(line: line)
                let tokens = convertWordsToTokens(words)
                tokensForLines.append(tokens)
                print("tokens show", words)
                
            }
            
            if (line.hasPrefix("check")) {
                
                var (conditions, yesBlock, elseBlock, remaining) = parseStringFor(input: line)
                
                if remaining.contains("if") && remaining.contains("is") {
                    
                    remaining = CommonFunctions().removeWordsBetweenWords(in: remaining, firstWord: "if", secondWord: "is")
                    
                }
                
                if remaining.contains("do") && remaining.contains("else") {
                    
                    remaining = CommonFunctions().removeWordsBetweenWords(in: remaining, firstWord: "do", secondWord: "else")
                    
                }
                
                if remaining.contains("else") && remaining.contains("then") {
                    
                    remaining = CommonFunctions().removeWordsBetweenWords(in: remaining, firstWord: "else", secondWord: "then")
                    
                }

                let tokens = stringToTokensForCheck(remaining: remaining, conditions: conditions, yesBlock: yesBlock, elseBlock: elseBlock)
                
                tokensForLines.append(tokens)
                
            }
        }
        
        return tokensForLines
    }
    
}
