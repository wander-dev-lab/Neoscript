enum TokenType {
    case keyword
    case datatype
    case identifier
    case op
    case constant
    case condition
    case yesBlock
    case elseBlock
}

struct Token {
    let value: String
    let type: TokenType
}
