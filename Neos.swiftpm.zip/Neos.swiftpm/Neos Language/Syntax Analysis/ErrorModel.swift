import Foundation

struct ErrorModel {
    let lineNumber: Int?
    let isValid: Bool
    let errorMessage: String?
    
    init(lineNumber: Int? = nil, isValid: Bool, errorMessage: String? = nil ) {
        self.lineNumber = lineNumber
        self.isValid = isValid
        self.errorMessage = errorMessage
    }
}
