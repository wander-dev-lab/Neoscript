import Foundation

class SyntaxAnalyser
{
    
    func hasIdentifierToken(_ tokens: [Token]) -> Bool {
        for token in tokens {
            if (token.type == .identifier ) {
                return true
            }
        }
        return false
    }
    
    func areListsEqual<T: Equatable>(_ list1: [T], _ list2: [T]) -> Bool {
        // Check if the lists have the same number of elements
        guard list1.count == list2.count else {
            return false
        }
        
        // Iterate over the elements of both lists and compare them
        for (element1, element2) in zip(list1, list2) {
            if element1 != element2 {
                // If any elements differ, the lists are not equal
                return false
            }
        }
        
        // If all elements are equal, the lists are equal
        return true
    }
    
    func checkSyntaxForThink(tokensOfLine: [Token], lineNumber: Int) -> ErrorModel {
        if tokensOfLine.count < 5 {
            return ErrorModel( lineNumber: lineNumber+1, isValid: false, errorMessage: "Syntax Error")
        }
        
        // Check if the first token is the keyword "think"
        guard tokensOfLine[0].type == .keyword && tokensOfLine[0].value == "think" else {
            return ErrorModel(lineNumber: lineNumber+1, isValid: false, errorMessage: "Expected keyword 'think'")
        }
        
        let tokenTypes = checkTokenTypes(in: tokensOfLine)
        
        if(!tokenTypes.containsKeyword)
        {
            return ErrorModel( lineNumber: lineNumber+1, isValid: false, errorMessage: "No keyword is provided")
        }
        
        if(!tokenTypes.containsDatatype)
        {
            return ErrorModel( lineNumber: lineNumber+1, isValid: false, errorMessage: "No datatype is provided")
        }
        if(!tokenTypes.containsIdentifier)
        {
            return ErrorModel( lineNumber: lineNumber, isValid: false, errorMessage: "No identifier is provided")
        }
        if(!tokenTypes.containsOperator)
        {
            return ErrorModel( lineNumber: lineNumber+1, isValid: false, errorMessage: "No operator is provided")
        }
        if(!tokenTypes.containsConstant)
        {
            return ErrorModel( lineNumber: lineNumber+1, isValid: false, errorMessage: "No constant value is provided")
        }
        
        return ErrorModel(isValid: true)
        
    }
    
    func hasCorrectParentheses(_ string: String) -> Bool {
        var openCount = 0
        for char in string {
            if char == "(" {
                openCount += 1
            } else if char == ")" {
                if openCount == 0 {
                    // If we encounter a closing parenthesis without a corresponding opening parenthesis, return false
                    return false
                }
                openCount -= 1
            }
        }
        // If openCount is 0 at the end, it means all opening parentheses have been matched with closing parentheses
        return openCount == 0
    }
    
    func containsOnlyAlphabets(_ string: String) -> Bool {
        // Iterate through each character in the string
        for character in string {
            // Check if the character is not a letter
            if !character.isLetter {
                return false
            }
        }
        // If all characters are letters, return true
        return true
    }
    
    func reverseWords(condition: String) -> String {
        
        var l:Int = 0
        var n:Int = condition.count
        var r:Int = n - 1
        var ee:Int = r
        var ans: String = ""
        
        while (l <= r) {
            
            while (r >= 0 && condition[condition.index(condition.startIndex, offsetBy: r)] == " ") {
                r = r - 1
            }
            
            if r < 0 {
                break
            }
            
            ee = r
            
            while (r >= 0 && condition[condition.index(condition.startIndex, offsetBy: r)] != " ") {
                r = r - 1
            }
            
            let startIndex = condition.index(condition.startIndex, offsetBy: r + 1)
            let endIndex = condition.index(condition.startIndex, offsetBy: ee - 1)
            ans += String(condition[startIndex...endIndex])
            
            ans.append(" ")

        }
        
        let _ = ans.popLast()
        return ans
        
    }
    
    func addSpaces(to string: String) -> String {
        var result = ""
        
        let operators = ["&&", "||"]
        
        for (index, char) in string.enumerated() {
            result.append(char)
            
            if index < string.count - 1 {
                let nextCharIndex = string.index(string.startIndex, offsetBy: index + 1)
                let nextChar = string[nextCharIndex]
                
                // Add space after character if next character is not a space and not an operator
                if char != " " && nextChar != " " && !operators.contains("\(char)\(nextChar)") {
                    result.append(" ")
                }
            }
        }
        
        return result
    }
    
    func isValidCondition(string: String) -> (Bool, [String]) {
        let conditionCharList = string.trimmingCharacters(in: .whitespacesAndNewlines)
            .components(separatedBy: " ")
        
        var output: [String] = []
        var stack: [String] = []
        
        for char in conditionCharList {
            switch char {
            case "(":
                stack.append(char)
            case ")":
                while let top = stack.last, top != "(" {
                    output.append(stack.removeLast())
                }
                stack.removeLast() // Remove the "("
            case "&&", "||", ">", "<", "==", "!=", ">=", "<=":
                while let top = stack.last, precedence(top) >= precedence(char), top != "(" {
                    output.append(stack.removeLast())
                }
                stack.append(char)
            default:
                output.append(char)
            }
        }
        
        // Append remaining operators to output
        while let op = stack.popLast() {
            output.append(op)
        }
        
        return (true, output)
    }
    
    func precedence(_ op: String) -> Int {
        switch op {
        case "||": return 1
        case "&&": return 2
        case "==", "!=", ">", "<", ">=", "<=": return 3
        default: return 0
        }
    }
    
    func checkSyntaxForIf(tokens: [Token], commandNumber: Int) -> (ErrorModel, [String]) {
        
//        print(tokens)
//        print("from checkSyntax", tokens)
        guard tokens.count >= 10 else {
            return (ErrorModel(lineNumber: commandNumber+1,isValid: false, errorMessage: "Insufficient number of tokens."), [])
        }
        
        // Check if the first token is "check"
        guard tokens[0].value.lowercased() == "check" else {
            return (ErrorModel(lineNumber: commandNumber+1,isValid: false, errorMessage: "First token must be \"check\"."), [])
        }
        
        // Check if the first token is "check"
        guard tokens[1].value.lowercased() == "if" else {
            return (ErrorModel(lineNumber: commandNumber+1,isValid: false, errorMessage: "Second token must be \"if\"."), [])
        }
        
        // Check if the third token is a valid condition
        let conditionToken = tokens[2]
        let (isConditionValid, conditions) = isValidCondition(string: conditionToken.value)
//        print("from checkForIf")
//        print("from checkForIf")
//        print(isConditionValid)
        if conditionToken.type != .condition || !isConditionValid {
            return (ErrorModel(lineNumber: commandNumber+1,isValid: false, errorMessage: "Invalid condition."), [])
        }
        
        // Check if the fourth token is "is"
        guard tokens[3].value.lowercased() == "is" else {
            return (ErrorModel(lineNumber: commandNumber+1,isValid: false, errorMessage: "Fourth token must be \"is\"."), [])
        }
        
        // Check if the fifth token is "yes"
        guard tokens[4].value.lowercased() == "yes" else {
            return (ErrorModel(lineNumber: commandNumber+1,isValid: false, errorMessage: "Fifth token must be \"yes\"."), [])
        }
        
        // Check if the sixth token is "do"
        guard tokens[5].value.lowercased() == "do" else {
            return (ErrorModel(lineNumber: commandNumber+1,isValid: false, errorMessage: "Sixth token must be \"do\"."), [])
        }
        
        // Check if the seventh token is "do"
        guard tokens[6].type == .yesBlock else {
            return (ErrorModel(lineNumber: commandNumber+1,isValid: false, errorMessage: "Seventh token must be yes block"), [])
        }
        
        // Check if the eight token is "else"
        guard tokens[7].value.lowercased() == "else" else {
            return (ErrorModel(lineNumber: commandNumber+1,isValid: false, errorMessage: "Eight token must be \"else\"."), [])
        }
        
        // Check if the ninth token is "do"
        guard tokens[8].type == .elseBlock else {
            return (ErrorModel(lineNumber: commandNumber+1,isValid: false, errorMessage: "Ninth token must be else block"), [])
        }
        
        // Check if the tenth token is "then"
        guard tokens[9].value.lowercased() == "then" else {
            return (ErrorModel(lineNumber: commandNumber+1,isValid: false, errorMessage: "Tenth token must be \"then\"."), [])
        }
        
        // Check if the last token is "stop"
        guard tokens.last?.value.lowercased() == "stop" else {
            return (ErrorModel(lineNumber: commandNumber+1, isValid: false, errorMessage: "Last token must be \"stop\"."), [])
        }
        
        // If all checks pass, the syntax is correct
        //        print(conditions)
        return (ErrorModel(isValid: true), conditions)
    }
    
    func checkSyntaxForShow(tokens: [Token], commandNumber: Int) -> ErrorModel {
        
        guard tokens.count >= 2 else {
            return ErrorModel(lineNumber: commandNumber+1, isValid: false, errorMessage: "Insufficiant tokens")
        }
        
        guard isValidIdentifierName(tokens[1].value) || Int(tokens[1].value) != nil || tokens[1].value.contains("/") || tokens[1].value.contains(" ") || Float(tokens[1].value) != nil || Double(tokens[1].value) != nil || String(tokens[1].value) != nil || Bool(tokens[1].value) != nil else {
            return ErrorModel(lineNumber: commandNumber+1, isValid: false, errorMessage: "No value is specified")
        }
        
        guard !Lists.datatypeList.contains(tokens[1].value) else {
            return ErrorModel(lineNumber: commandNumber+1, isValid: false, errorMessage: "Should not contain any datatype")
        }
        
        guard !Lists.keywordList.contains(tokens[1].value) else {
            return ErrorModel(lineNumber: commandNumber+1, isValid: false, errorMessage: "Should not contain any keyword")
        }
        
        return ErrorModel(isValid: true)
        
    }

    func checkSyntaxForUpdate(tokens: [Token], commandNumber: Int) -> ErrorModel {
        
        guard tokens.count >= 4 else {
            return ErrorModel(lineNumber: commandNumber+1, isValid: false, errorMessage: "Insufficiant tokens")
        }
        
        let tokenTypes = checkTokenTypes(in: tokens)
        
        guard tokenTypes.containsIdentifier && isValidIdentifierName(tokens[1].value) else {
            return ErrorModel(lineNumber: commandNumber+1, isValid: false, errorMessage: "No identifier is specified")
        }
        
        guard tokens[2].value == "with" else {
            return ErrorModel(lineNumber: commandNumber+1, isValid: false, errorMessage: "No operator is specified")
        }
        
        guard tokenTypes.containsConstant else {
            return ErrorModel(lineNumber: commandNumber+1, isValid: false, errorMessage: "No constant value is specified")
        }
        
        return ErrorModel( isValid: true)
        
    }
    
    func isValidIdentifierName(_ name: String) -> Bool {
        let pattern = "^[a-zA-Z_][a-zA-Z0-9_]*$"
        return name.range(of: pattern, options: .regularExpression) != nil
    }
    
    func checkTokenTypes(in tokens: [Token]) -> (containsKeyword: Bool, containsDatatype: Bool, containsIdentifier: Bool, containsOperator: Bool, containsConstant: Bool) {
        var containsKeyword = false
        var containsDatatype = false
        var containsIdentifier = false
        var containsOperator = false
        var containsConstant = false
        
        for token in tokens {
            switch token.type {
            case .keyword:
                containsKeyword = true
            case .datatype:
                containsDatatype = true
            case .identifier:
                containsIdentifier = true
            case .op:
                containsOperator = true
            case .constant:
                containsConstant = true
            default:
                break
            }
        }
        
        return (containsKeyword, containsDatatype, containsIdentifier, containsOperator, containsConstant)
    }
    
    func firstAppearance(of type: TokenType, in tokens: [Token]) -> Int? {
        for (index, token) in tokens.enumerated() {
            if token.type == type {
                return index
            }
        }
        return nil // Return nil if the type is not found
    }
    
    func analyse(tokensOfLines: [[Token]]) -> ( ErrorModel, [[String]]) {
        var conditionsList: [[String]] = []
        var errorsForSyntax: [ErrorModel] = []
        
        print("tokens", tokensOfLines)
        
        for ( commandNumber, tokensOfLine) in tokensOfLines.enumerated() {
            if tokensOfLine.first?.type == .keyword {
                switch tokensOfLine.first?.value {
                case "think": 
                    errorsForSyntax.append(checkSyntaxForThink(tokensOfLine: tokensOfLine, lineNumber: commandNumber))
                    break
                    
                case "check":
                    let (checkSyntaxIf, conditions) = checkSyntaxForIf(tokens: tokensOfLine, commandNumber: commandNumber)
//                    print("check if", checkSyntaxIf)
                    errorsForSyntax.append(checkSyntaxIf)
                    conditionsList.append(conditions)
//                    print(conditions)
                    break
                
                    
                case "update":
                    errorsForSyntax.append(checkSyntaxForUpdate(tokens: tokensOfLine, commandNumber: commandNumber))
                    break
                    
                case "show":
                    errorsForSyntax.append(checkSyntaxForShow(tokens: tokensOfLine, commandNumber: commandNumber))
                    print("errorsForSyntax", errorsForSyntax)
                    break
                    
                default:
                    break
                }
            }
            else if !tokensOfLine.isEmpty {
                errorsForSyntax.append(ErrorModel(lineNumber: commandNumber, isValid: false, errorMessage: "No keyword found"))
            }
            
        }
        
//        print("from analyse")
//        print(conditionsList)
        
//        var errorForDuplicateAtt: ErrorModel
        
//        print(conditionsList)
        
        errorsForSyntax = errorsForSyntax.filter { !$0.isValid }
        print("errors list", errorsForSyntax)

        var syntaxErrorMessage: String = ""
        
        if !errorsForSyntax.isEmpty{
            
            for syntaxError in errorsForSyntax {

                    if let lineNumber = syntaxError.lineNumber, let errorMessage = syntaxError.errorMessage {
                        syntaxErrorMessage += "\nError in command \(lineNumber): \(errorMessage)\n"
                    }

                    
//                    syntaxErrorMessage = String(syntaxError.lineNumber ?? -1)


            }
            
            syntaxErrorMessage = syntaxErrorMessage.trimmingCharacters(in: .whitespacesAndNewlines)


            return (ErrorModel(isValid: false, errorMessage:syntaxErrorMessage), conditionsList)
        }
        else {
            return (ErrorModel(isValid: true), conditionsList)
        }
        
    }

}
