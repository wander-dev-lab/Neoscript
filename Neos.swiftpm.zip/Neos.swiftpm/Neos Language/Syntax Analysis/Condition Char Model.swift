import Foundation

enum ConditionCharType {
    case variable
    case integer
    case float
    case double
    case string
    case logicalOp
    case compOp
    case paranthethis
    case bool
}

struct ConditionCharModel {
    let value: String
    let type: ConditionCharType
    let position: Int?
}
