import Foundation

class Executer{
    
    func getValueOfVar(tokens: [[Token]], variable: String) -> String? {
        for tokenList in tokens {
            if let firstToken = tokenList.first, firstToken.value == "think" {
                for token in tokenList {
                    if token.type == .identifier && token.value == variable {
                        for i in 0..<tokenList.count {
                            if tokenList[i].type == .op && tokenList[i].value == "=" && i + 1 < tokenList.count {
                                if tokenList[i + 1].type == .constant {
                                    return tokenList[i + 1].value
                                } else {
                                    return nil
                                }
                            }
                        }
                    }
                }
            }
        }
        return nil
    }
    
    func executeIf(tokens: [[Token]], condition: [String]) -> Bool {
        
        var stackInt = [String]()
        var stackBool = [Bool]()
        let operators = [">", "<", "==", "!=", "<=", ">=", "true", "false"] 
        
        var mainValidity: Bool = false
        
        print("condition" , condition)
        
        for char in condition {
            
            print("stackInt", stackInt)
            print("stackBool", stackBool)
            
            if (char.allSatisfy({ $0.isLetter })
                || Int(char) != nil
                || Float(char) != nil
                || Double(char) != nil
                || Bool(char) != nil
                || char.contains("/")) {
                
                print("innerIdentifier", char)
                
                let index = SemanticAnalyser().lineIndexOfValue(tokensOfLines: tokens, value: char)
                
                var val: String?
                
                if index != nil {
                    let outputVal = SemanticAnalyser().getValueOfTheVar(tokensOfLines: tokens, index: index ?? -1)
                    val = outputVal?.value
                }
                
                print("varvalue", char, val ?? "nil")
                
                if val != nil {
                    stackInt.append(val ?? "")
                }
                else {
                    stackInt.append(char)
                }
                
            }
            
            else if ( char == "&&") {
                
                let op2Bool = stackBool.removeLast()
                let op1Bool = stackBool.removeLast()
                
                mainValidity = op2Bool && op1Bool
                
            }
            else if(char == "||") {
                
                let op2Bool = stackBool.removeLast()
                let op1Bool = stackBool.removeLast()
                
                mainValidity = op2Bool || op1Bool
                
            }
            else if ( operators.contains(char) ) {
                let operand2 = stackInt.removeLast()
                let operand1 = stackInt.removeLast()
                
                var validity: Bool = false
                
                switch char {
                    
                case ">":
                    validity = operand1 > operand2
                    stackBool.append(validity)
                    mainValidity = validity
                    break
                    
                case "<":
                    validity = operand1 < operand2
                    stackBool.append(validity)
                    mainValidity = validity
                    break
                    
                case "==":
                    validity = operand1 == operand2
                    stackBool.append(validity)
                    mainValidity = validity
                    break
                    
                case "!=":
                    validity = operand1 != operand2
                    stackBool.append(validity)
                    mainValidity = validity
                    break
                    
                case "<=":
                    validity = operand1 <= operand2
                    stackBool.append(validity)
                    mainValidity = validity
                    break
                    
                case ">=":
                    validity = operand1 >= operand2
                    stackBool.append(validity)
                    mainValidity = validity
                    break
                    
                case "true":
                    validity = operand1 == operand2
                    stackBool.append(validity)
                    mainValidity = validity
                    break
                    
                case "false":
                    validity = operand1 != operand2
                    stackBool.append(validity)
                    mainValidity = validity
                    break
                    
                default:
                    break
                    
                }
                
            }
            
        }
        
        return mainValidity
        
    }
    
    func findParts(tokens: [Token], checked: Bool) -> [Token] {
        let filteredTokens = tokens.filter { token in
            if checked {
                return token.type == .yesBlock
            } else {
                return token.type == .elseBlock
            }
        }
        return filteredTokens
    }
    
    func formatStringList(_ strings: [String]) -> [String] {
        var formattedStrings = [String]()
        
        for str in strings {
            if str.hasPrefix("* ") {
                let startIndex = str.index(str.startIndex, offsetBy: 2)
                let substring = str[startIndex...]
                formattedStrings.append(String(substring))
            } else {
                formattedStrings.append(str)
            }
        }
        
        return formattedStrings
    }
    
    var globalOutput = [String]()
    
    func splitAndMergeLines(input: String) -> [String] {
        let lines = input.components(separatedBy: "\n")
        var result: [String] = []
        var currentBlock: [String] = []
        
        for line in lines {
            if line.hasPrefix("* ") {
                if line.contains("check") {
                    // Append current block to result and start a new block
                    if !currentBlock.isEmpty {
                        result.append(currentBlock.joined(separator: "\n"))
                        currentBlock = []
                    }
                    currentBlock.append(String(line.dropFirst(2)))
                } else {
                    // Append line to current block
                    currentBlock.append(String(line.dropFirst(2)))
                }
            } else {
                // Append line to current block
                currentBlock.append(line)
            }
        }
        
        if !currentBlock.isEmpty {
            result.append(currentBlock.joined(separator: "\n"))
        }
        
        return result
    }
    
    func execute(tokens: inout [[Token]], conditions: [[String]]?) -> [String] {
        
        var executionList: [String] = []
        var conditionList = [Int: Bool]()
        var innerTokens = [[Token]]()
        var updatedTokens = tokens
        
        print("conditions", conditions)
        
        for (index, token) in updatedTokens.enumerated() {
            
            var output: String = ""
            
            if token.first?.value == "think" {
                
                var identifier: String = ""
                var constant: String = ""
                var type: String = ""
                
                for word in token{
                    
                    if word.type == .datatype {
                        type = word.value
                    }
                    
                    if word.type == .identifier {
                        identifier = word.value
                    }
                    
                    if word.type == .constant {
                        constant = word.value
                    }
                    
                }
                
                output += "\nIdentifier \(identifier) of Datatype \(type) is created with value \(constant)\n"
            }
            
            if token.first?.value == "update" {
                
                let index = SemanticAnalyser().lineIndexOfValue(tokensOfLines: updatedTokens, value: token[1].value ?? "") ?? -1
                _ = token[1].value
                
                if index != -1 {
                    
                        let updatedToken = Token(value: token.last?.value ?? "", type: .constant)
                        // Update the value of the constant at the specified index
                    updatedTokens[index][4] = updatedToken
                    
                    output += "\nThe value of \(token[1].value) is updated to \(token.last?.value ?? "")\n"

                }
                
                print("updated", updatedTokens)
                
                
                
            }
            
            if token.first?.value == "show" {
                
                if token.last?.type == .identifier {
                    _ = SemanticAnalyser().filterTokens(tokensOfLines: updatedTokens, key: "think")
                    
                    let (identifierVal, _) = SemanticAnalyser().getValueOfTheVar(tokensOfLines: updatedTokens, index: SemanticAnalyser().lineIndexOfValue(tokensOfLines: updatedTokens, value: token.last?.value ?? "") ?? -1) ?? ("", "")
                    
                    output += "\nShowing value of \(token.last?.value ?? "") is \(identifierVal)\n"
                }
                else {
                    output += "\nShowing: \(token.last?.value ?? "")\n"
                }
                
            }
            
            if token.first?.value == "check" && conditions != nil {
                
                for condition in conditions ?? [] {
                    conditionList[index] = executeIf(tokens: updatedTokens, condition: condition)
                }
                
                let filteredToken = findParts(tokens: token, checked: conditionList[index] ?? false)
                
                for word in filteredToken {
                    
                    var allLines = splitAndMergeLines(input: word.value)
                    
                    allLines = formatStringList(allLines)
                    
                    let finalString = allLines.joined(separator: "\n")
                    
                    innerTokens = LexicalAnalyser().analyse(from: finalString)
                    
                    var (analysisError, conditions) = SyntaxAnalyser().analyse(tokensOfLines: updatedTokens)
//                    analysisError = analysisError2
                    
                    if analysisError.isValid {
                        analysisError = SemanticAnalyser().analyse(tokensOfLines: updatedTokens, conditions: conditions)
                    }
                    
                    if analysisError.isValid {
                        let innerOutputs = execute(tokens: &innerTokens, conditions: conditions)
                        print("inner", innerTokens)
                        output = innerOutputs.joined(separator: "\n")
                    }
                    
                    print("analysisError", analysisError)
                    
                }
                       
            }
            
            output = output.trimmingCharacters(in: .whitespacesAndNewlines)
            
            executionList.append(output)
        }
        
        return executionList
        
    }
        
}
