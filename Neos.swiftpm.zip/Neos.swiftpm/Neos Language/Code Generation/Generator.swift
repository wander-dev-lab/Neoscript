import Foundation

class Generator {
    
    func capitalizeFirstCharacter(_ input: String) -> String {
        guard let firstChar = input.first else { return input }
        return String(firstChar).uppercased() + input.dropFirst()
    }
    
    func generate(tokens: [[Token]]) -> [String] {
        
        let commonFunctions = CommonFunctions()
        
        var swiftCodeList: [String] = []
        
        for tokensOfLine in tokens {
            
            var swiftCode: String = ""
            
            if tokensOfLine.first?.value == "think" {
                
                swiftCode = "var"
                
                swiftCode += " \(tokensOfLine[2].value)"
                
                swiftCode += ": \(capitalizeFirstCharacter(tokensOfLine[1].value))"
                
                swiftCode += " ="
                
                let code: String = tokensOfLine[1].value == "string" ? " \"\(commonFunctions.formatQuotedString((tokensOfLine[4].value)))\"" :  " \(commonFunctions.formatQuotedString((tokensOfLine[4].value)))"
                
                swiftCode +=  code
                
            }
            
            swiftCodeList.append(swiftCode)
            
        }
        
        return swiftCodeList
    }
    
    func getSwiftCode(tokens: [[Token]]) -> ErrorModel {
        
        return ErrorModel(isValid: true, errorMessage: generate(tokens: tokens).joined(separator: "\n"))
        
    }
}
