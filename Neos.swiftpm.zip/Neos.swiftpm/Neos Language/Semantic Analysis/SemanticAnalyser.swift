import Foundation

class SemanticAnalyser
{

    
    func checkforDuplicateAtt(tokensOfLines: [[Token]], lineNumber: Int, identifier: String) -> ErrorModel {
        // Filter tokens to include only lines containing the "think" keyword
        let filteredAllTokens = filterTokens(tokensOfLines: tokensOfLines, key: "think")
        
        // Filter the filtered tokens to include only lines with the provided identifier
        let matchingTokens = filteredAllTokens.filter { tokens in
            guard tokens.count > 2, let token = tokens[2] ?? nil else { return false }
            return token.type == .identifier && token.value == identifier
        }
        
        // Check if there are more than one line with the same identifier
        if matchingTokens.count > 1 {
            return ErrorModel(isValid: false, errorMessage: "Duplicate identifier \(identifier) found.")
        } else {
            return ErrorModel(isValid: true)
        }
    }
    
    func containsOnlyIntegers(_ str: String) -> Bool {
        return Int(str) != nil
    }
    
    func containsFloatValue(_ str: String) -> Bool {
        let regex = #"[-+]?[0-9]*\.?[0-9]+"#
        return NSPredicate(format: "SELF MATCHES %@", regex).evaluate(with: str)
    }
    
    func containsStringValue(_ str: String) -> Bool {
        for char in str {
            if !char.isASCII {
                return false
            }
        }
        return true
    }
    
    func containsDoubleValue(_ str: String) -> Bool {
        return Double(str) != nil
    }
    
    func containsBoolValue(_ str: String) -> Bool {
        return str.lowercased() == "true" || str.lowercased() == "false"
    }
    
    func checkValueAndDatatype(tokensOfLines: [[Token]]) -> ErrorModel{
        
        var messageList: [String] = []
        var message: String = ""
//        print("tokensOfLines", tokensOfLines)
        
        for (line, tokensOfLine) in tokensOfLines.enumerated() {
            
            if(tokensOfLine.first?.value == "think") {
                
                switch tokensOfLine[1].value {
                    
                case "int":
                    message += containsOnlyIntegers(tokensOfLine[4].value) ? "" : "\nAt line \(line+1) Constant value \(tokensOfLine[4].value) does not match with the datatype \(tokensOfLine[1].value)\n"
                    
                case "string":
                    message += containsStringValue(tokensOfLine[4].value) ? "" : "\nAt line \(line+1) Constant value \(tokensOfLine[4].value) does not match with the datatype \(tokensOfLine[1].value)\n"
                    
                case "float":
                    message += containsFloatValue(tokensOfLine[4].value) ? "" : "\nAt line \(line+1) Constant value \(tokensOfLine[4].value) does not match with the datatype \(tokensOfLine[1].value)\n"
                    
                case "double":
                    message += containsDoubleValue(tokensOfLine[4].value) ? "" : "\nAt line \(line+1) Constant value \(tokensOfLine[4].value) does not match with the datatype \(tokensOfLine[1].value)\n"
                    
                case "bool":
                    message += containsBoolValue(tokensOfLine[4].value) ? "" : "\nAt line \(line+1) Constant value \(tokensOfLine[4].value) does not match with the datatype \(tokensOfLine[1].value)\n"
                    
                default:
                    break
                    
                }
                
            }
            
            if (tokensOfLine.first?.value == "update") {
                
                                
                let filteredTokens = filterTokens(tokensOfLines: tokensOfLines, key: "think")
                
                
                if !filteredTokens.isEmpty {
                    
                    var lineIndex: Int?
                    var val: (value: String, datatype: String)?
                    
                    for token in tokensOfLine {
                        
                        if token.type == .identifier {
                            lineIndex = lineIndexOfValue(tokensOfLines: tokensOfLines, value: token.value)
                            
                        }
                        
                        if token.type == .constant {
                            
                            if lineIndex != nil {
                                if let outputVal = getValueOfTheVar(tokensOfLines: tokensOfLines, index: lineIndex ?? -1) {
                                    
                                    val = outputVal
                                    
                                    if val != nil {
                                        
                                        switch val!.datatype {
                                        case "int":
                                            message += containsOnlyIntegers(tokensOfLine[3].value) ? "" : "At line \(line+1) Constant value \(tokensOfLine[3].value) does not match with the datatype \(val!.datatype)"
                                            
                                        case "string":
                                            message = containsStringValue(tokensOfLine[3].value) ? "" : "At line \(line+1) Constant value \(tokensOfLine[3].value) does not match with the datatype \(val!.datatype)"
                                            
                                        case "float":
                                            message = containsFloatValue(tokensOfLine[3].value) ? "" : "At line \(line+1) Constant value \(tokensOfLine[3].value) does not match with the datatype \(val!.datatype)"
                                            
                                        case "double":
                                            message = containsDoubleValue(tokensOfLine[3].value) ? "" : "At line \(line+1) Constant value \(tokensOfLine[3].value) does not match with the datatype \(val!.datatype)"
                                            
                                        case "bool":
                                            message = containsBoolValue(tokensOfLine[3].value) ? "" : "At line \(line+1) Constant value \(tokensOfLine[3].value) does not match with the datatype \(val!.datatype)"
                                            
                                        default:
                                            break
                                        }
                                        
                                    }
                                    
                                }
                            }
                        }
                        
                    }
                    
                }
                
                else {
                    message += "\nThe provided identifier is not declared in the scope\n"
                }
            }
            
            if tokensOfLine.first?.value == "show" && tokensOfLine.last?.type == .identifier {
                
                let filteredTokens = filterTokens(tokensOfLines: tokensOfLines, key: "think")
                
                if filteredTokens.isEmpty {
                    message += "\nThe provided identifier is not declared in the scope\n"
                }
                
            }
            
        }
        
        if !message.isEmpty {
            return ErrorModel(isValid: false, errorMessage: message.trimmingCharacters(in: .whitespacesAndNewlines))
        }
        else {
            return ErrorModel(isValid : true)
        }
        
    }
    
    func filterTokens(tokensOfLines: [[Token]], key: String) -> [[Token]] {
        // Filter the 2D array based on the condition
        return tokensOfLines.filter { $0.first?.value.lowercased() == key }
    }
    
    func lineIndexOfValue(tokensOfLines: [[Token]], value: String) -> Int? {
        // Iterate through each inner array
        for (index, tokens) in tokensOfLines.enumerated() {
            // Check if any token's value matches the given value
            if tokens.contains(where: { $0.value == value && $0.type == .identifier }) {
                return index
            }
        }
        // If the value is not found in any inner array, return nil
        return nil
    }
    
    func getValueOfTheVar(tokensOfLines: [[Token]], index: Int) -> (value: String, datatype: String)? {
        var output: (value: String, datatype: String) = ("", "") // Initialize the tuple
        
        for token in tokensOfLines[index] {
            if token.type == .datatype {
                output.datatype = token.value
            }
            if token.type == .constant {
                output.value = token.value
            }
        }
        
        // Check if both value and datatype are set
        guard !output.value.isEmpty && !output.datatype.isEmpty else {
            return nil // Return nil if either value or datatype is missing
        }
        
        return output
    }
    
    func checkConditionType(tokensOfLines: [[Token]], conditions: [[String]]) -> ErrorModel{
        
        let tokensOfLinesAfterFilter = filterTokens(tokensOfLines: tokensOfLines, key: "think")
        
        var message: String = ""
        var isValid: Bool = true
        
        //        print("chars", conditions)
        for condition in conditions {
            for (line, charList) in condition.enumerated() {
                let char = charList.components(separatedBy: " ")
                var lineNumber: Int = -1
                var identifier: String = ""
                for word in char {
                    
                    //                    print("char:")
                    //                    print(char.count)
                    //                    print("word:")
                    //                    print(word)
                    
                    //                    print(lineNumber)
                    
                    if SyntaxAnalyser().containsOnlyAlphabets(word) && !word.hasPrefix("/") && !word.hasSuffix("/") && Bool(word) == nil {
                        print("only alpha \(word)")
                        let index = lineIndexOfValue(tokensOfLines: tokensOfLinesAfterFilter, value: word)
                        if (index != nil) {
                            
                            identifier = word
                            lineNumber = index ?? -1
//                            print("indx")
//                            print(index)
                            
                            if let _ = getValueOfTheVar(tokensOfLines: tokensOfLinesAfterFilter, index: index ?? -1) {
                                
                                isValid = true

                            }
                            else {
                                
                                isValid = false
                                message += "\n\nSomething wrong happend for the value of \(word)"
                                
                            }
                            
                        }
                        else {
                            isValid = false
                            message += "\n\nError: \"\(word)\" is not created in the scope"
                        }
                        

                        
                    }
                    
                    else if containsStringValue(word) && (word.hasPrefix("/") && word.hasSuffix("/")) {
                        
                        if lineNumber != -1 {
                            
                            let vals = getValueOfTheVar(tokensOfLines: tokensOfLinesAfterFilter, index: lineNumber)
                            
                            if vals?.datatype == "string" {
                                
                                isValid = true
                                
                            }
                            else {
                                
                                isValid = false
                                message += "\n\nError: The datatype of \"\(identifier)\" is not matching for strings"
                                
                            }
                            
                        }
                        else {
//                            isValid = false
//                            message += "\n\nError at line \(line+1): \"\(identifier)\" is not created in the scope 2"
                        }
                        
//                        let (validity, errorMessage) = checkConditionVars(tokensOfLinesAfterFilter: tokensOfLinesAfterFilter, lineNumber: lineNumber, line: line, identifier: identifier, targetDatatype: "string")
//                        
//                        isValid = validity
//                        message += errorMessage
                        
                        
                        message = message.trimmingCharacters(in: .whitespacesAndNewlines)
                        
                    }
                    
                    else if containsOnlyIntegers(word) {
//                        print("int", word)
                        
                        if lineNumber != -1 {
                            
                            let vals = getValueOfTheVar(tokensOfLines: tokensOfLinesAfterFilter, index: lineNumber)
                            
                            if vals?.datatype == "int" {
                                
                                isValid = true
//                                print("from validity int",isValid)
                                
                            }
                            else {
                                
                                isValid = false
                                message += "\n\nError: The datatype of \"\(identifier)\" is not matching for integers"
                                
                            }
                            
                        }
                        else {
//                            isValid = false
//                            message += "\n\nError at line \(line+1): \"\(identifier)\" is not created in the scope 3"
                        }
                        
                        message = message.trimmingCharacters(in: .whitespacesAndNewlines)
                        
                    }
                    
                    else if containsDoubleValue(word) {
                        
                        if lineNumber != -1 {
                            
                            let vals = getValueOfTheVar(tokensOfLines: tokensOfLinesAfterFilter, index: lineNumber)
                            
                            if vals?.datatype == "double" {
                                
                                isValid = true
                                
                            }
                            else {
                                
                                isValid = false
                                message += "\n\nError: The datatype of \"\(identifier)\" is not matching for doubles"
                                
                            }
                            
                        }
                        else {
//                            isValid = false
//                            message += "\n\nError at line \(line+1): \"\(identifier)\" is not created in the scope 4"
                        }
                        
                        message = message.trimmingCharacters(in: .whitespacesAndNewlines)
                        
                    }
                    
                    else if containsFloatValue(word) {
                        
                        if lineNumber != -1 {
                            
                            let vals = getValueOfTheVar(tokensOfLines: tokensOfLinesAfterFilter, index: lineNumber)
                            
                            if vals?.datatype == "float" {
                                
                                isValid = true
                                
                            }
                            else {
                                
                                isValid = false
                                message += "\n\nError: The datatype of \"\(identifier)\" is not matching for floats"
                                
                            }
                            
                        }
                        else {
//                            isValid = false
//                            message += "\n\nError at line \(line+1): \"\(identifier)\" is not created in the scope 5"
                        }
                        
                        message = message.trimmingCharacters(in: .whitespacesAndNewlines)
                        
                    }
                    
                    else if containsBoolValue(word) {
                        
                        if lineNumber != -1 {
                            
                            let vals = getValueOfTheVar(tokensOfLines: tokensOfLinesAfterFilter, index: lineNumber)
                            
                            if vals?.datatype == "bool" {
                                
                                isValid = true
                                
                            }
                            else {
                                
                                isValid = false
                                message += "\n\nError: The datatype of \"\(identifier)\" is not matching for bools"
                                
                            }
                            
                        }
                        else {
//                            isValid = false
//                            message += "\n\nError at line \(line+1): \"\(identifier)\" is not created in the scope 6"
                        }
                        
                        message = message.trimmingCharacters(in: .whitespacesAndNewlines)
                        
                    }
                    
                }
            }
        }
        
//        print("valid",isValid)
        message = message.trimmingCharacters(in: .whitespacesAndNewlines)
        
        return ErrorModel(isValid: isValid, errorMessage: message)
        
    }
    
    func checkConditionVars(tokensOfLinesAfterFilter: [[Token]],lineNumber: Int, line:Int, identifier:String, targetDatatype: String) -> (Bool, String) {
        
        var isValid: Bool = false
        var message: String = ""
        
        if lineNumber != -1 {
            
            let vals = getValueOfTheVar(tokensOfLines: tokensOfLinesAfterFilter, index: lineNumber)
            
            if vals?.datatype == targetDatatype {
                isValid = true
            }
            else {
                isValid = false
                message = "\n\nError at line \(line+1): the datatype of \"\(identifier)\" is not matching"
            }
            
        }
        else {
            isValid = false
            message = "\n\nError at line \(line+1): \"\(identifier)\" is not created in the scope"
        }
        
        return (isValid, message)
    }
    
    func analyse(tokensOfLines: [[Token]], conditions: [[String]]?) -> ErrorModel {
        
        var errors: [ErrorModel] = [ErrorModel(lineNumber: nil, isValid: true, errorMessage: "")]
        
        for (lineNumber, tokensOfLine) in tokensOfLines.enumerated() {
            
            if tokensOfLine.first?.value == "think" {
                
                let error: ErrorModel = checkforDuplicateAtt(tokensOfLines: tokensOfLines, lineNumber: lineNumber, identifier: tokensOfLine[2].value)
                
                if error.isValid {
                    
                    errors.append( checkValueAndDatatype(tokensOfLines: tokensOfLines))
                    
                }
                else {
                    errors.append(error)
                }
                
            }
//            print("errors1", errors)
            if tokensOfLine.first?.value == "update" {
                let error = checkValueAndDatatype(tokensOfLines: tokensOfLines)
                errors.append(error)
//                print("errors", errors)
            }
            
            if tokensOfLine.first?.value == "show" {
                let error = checkValueAndDatatype(tokensOfLines: tokensOfLines)
                errors.append(error)
                //                print("errors", errors)
            }
            
            if tokensOfLine.first?.value == "check" {
                
                if conditions != nil && !conditions!.isEmpty {
                    
                    errors.append(checkConditionType(tokensOfLines: tokensOfLines, conditions: conditions ?? []))
                    
                }
                
            }
            
        }
        
//        print(errors)
        errors = errors.filter{$0.isValid == false}
        
        var errorMessage:String  = ""
        
        if errors.isEmpty {
            
            return ErrorModel(isValid: true)
            
        }
        else {
            
            for error in errors {
                errorMessage += "\n\(error.errorMessage ?? "Uknown Error Found")\n"
            }
            
            errorMessage =
            errorMessage.trimmingCharacters(in: .whitespacesAndNewlines)
            
            return ErrorModel( isValid: false, errorMessage: errorMessage)
            
        }
        
    }
    
}
