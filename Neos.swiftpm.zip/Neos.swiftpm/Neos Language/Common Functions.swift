import Foundation

class CommonFunctions {
    
    func formatQuotedString(_ input: String) -> String {
        var formattedString = input
        
        // Replace the first and last "/" with double quotes
        if let firstIndex = formattedString.firstIndex(of: "/"),
           let lastIndex = formattedString.lastIndex(of: "/"),
           firstIndex != lastIndex {
            formattedString.replaceSubrange(firstIndex...firstIndex, with: "\"")
            formattedString.replaceSubrange(lastIndex...lastIndex, with: "\"")
        }
        
        return formattedString
    }
    
    func isFirstWordTarget(input: String, target: String) -> Bool {
        let components = input.components(separatedBy: .whitespaces)
        return components.first == target
    }
    
    func removeWordsBetweenWords(in input: String, firstWord: String, secondWord: String) -> String {
        // Split the input string by whitespace
        var words = input.components(separatedBy: .whitespaces)
        
        // Find the indices of the first and second words
        guard let firstIndex = words.firstIndex(of: firstWord),
              let secondIndex = words.firstIndex(of: secondWord) else {
            // If either of the words is not found, return the original input
            return input
        }
        
        // Remove words between the first and second words (excluding the first word)
        words.removeSubrange((firstIndex + 1)..<secondIndex)
        
        // Join the remaining words back into a string
        let result = words.joined(separator: " ")
        
        return result
    }
    
    func findIndex<T: Equatable>(list: [T], target: T) -> Int? {
        for (index, value) in list.enumerated() {
            if value == target {
                return index
            }
        }
        return nil
    }
    
}
