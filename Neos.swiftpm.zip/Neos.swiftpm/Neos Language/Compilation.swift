import Foundation

class Compilation
{
   
    func saveToFile(_ code: String) {
        let fileName = generateUniqueFileName()
        let filePath = URL(fileURLWithPath: FileManager.default.currentDirectoryPath).appendingPathComponent(fileName)
        
        do {
            try code.write(to: filePath, atomically: true, encoding: .utf8)
            print("Swift code saved to \(filePath.path)")
        } catch {
            print("Error saving Swift code: \(error.localizedDescription)")
        }
    }
    
    func generateUniqueFileName() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyyMMddHHmmss"
        let timestamp = dateFormatter.string(from: Date())
        
        let randomString = UUID().uuidString
        
        return "\(timestamp)_\(randomString)"
    }
    
    func compile(for input: String) -> ErrorModel{
        let lexicalAnalyser = LexicalAnalyser()
        let syntaxAnalyser = SyntaxAnalyser()
        let semanticAnalyser = SemanticAnalyser()
        let generator = Generator()
        
        var analysisError: ErrorModel = ErrorModel(lineNumber: nil, isValid: false, errorMessage: "Staring")
        
        let tokens = lexicalAnalyser.analyse(from: input)
        
        let (analysisError2, conditions) = syntaxAnalyser.analyse(tokensOfLines: tokens)
        analysisError = analysisError2
                
        if analysisError.isValid {
             analysisError = semanticAnalyser.analyse(tokensOfLines: tokens, conditions: conditions)
        }
        
        if analysisError.isValid {
            analysisError = generator.getSwiftCode(tokens: tokens)
        }
        
        return analysisError
        
    }

}
