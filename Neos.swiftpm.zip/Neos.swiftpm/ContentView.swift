import SwiftUI
import Foundation

struct ContentView: View {
    
    @State private var currentScreen: Screen = .main
    @State private var currentLearningScreen: LearningScreen = 
        .main("")
//        .conditional("conditional")
            @State var animation  = false
    @State private var nextString = ""
    
    var body: some View {
        
        NavigationStack {
            VStack{
                
                HStack(content: {
                    if currentScreen != .main && nextString.isEmpty{
                        Button(action: {
                            withAnimation(.easeInOut(duration: 0.5), {
                                nextString = ""
                                currentScreen = .main
                            })
                        }, label: {
                            Image(systemName: "arrow.left")
                                .font(.system(size: 30))
                                .padding(.leading, 10)
                                .padding(.trailing, 10)
                                .foregroundColor(.blue)
                        })
                    }
                    
                    if currentScreen == .learning && !nextString.isEmpty{
                        Button(action: {
                            withAnimation(.easeInOut(duration: 0.5), {
                                nextString = ""
                                currentLearningScreen = .main("")
                            })
                        }, label: {
                            Image(systemName: "arrow.left")
                                .font(.system(size: 30))
                                .padding(.leading, 10)
                                .padding(.trailing, 10)
                                .foregroundColor(.blue)
                        })
                    }
                    
                    if currentScreen == .aboutNeos {
                        Text("About")
                            .foregroundColor(.white)
                            .font(.system(size: 50, weight: .bold, design: .default))
                            .padding(.trailing, 5)
                    }
                    
                    Text("Neos")
                        .foregroundColor(currentScreen == .main ? .white : .blue)
                        .font(.system(size: 50, weight: .bold, design: .default))
                    
                    if currentScreen != .aboutNeos {
                        Text("\( currentScreen == .main ? "" : currentScreen.rawValue)")
                            .foregroundColor(.white)
                            .font(.system(size: 50, weight: .bold, design: .default))
                            .padding(.leading, 5)
//                            .onTapGesture(perform: {
//                                currentScreen = .learning
//                            })
                    }
                    
                    if currentScreen == .learning && !nextString.isEmpty {
                        Text(": \(nextString.replacingOccurrences(of: "#", with: " #").replacingOccurrences(of: "test", with: " Test"))")
                            .foregroundColor(.white)
                            .font(.system(size: 50, weight: .bold, design: .default))
                            .padding(.leading, 5)
                    }
                    
                    Spacer()
                    
                })
                .padding(.top, 15)
                .padding(.horizontal, 20)
                
                Spacer()
                
                switch currentScreen {
                case .main:
                    HomeButton(leadingIcon: "doc.append", title: "Learn", action: {
                        
                        withAnimation(.easeInOut(duration: 0.5), {
                            currentScreen = .learning
                        })
                    }).padding()
                    
                    HomeButton(leadingIcon: "keyboard", title: "Play", action: {
                        withAnimation(.easeInOut(duration: 0.5), {
                            currentScreen = .playground
                        })
                    }).padding()
                    
                    HomeButton(leadingIcon: "sparkles", title: "About", action: {
                        withAnimation(.easeInOut(duration: 0.5), {
                            currentScreen = .aboutNeos
                        })
                    }).padding()
                    
                case .learning:
                    LearningView(currentScreen: $currentLearningScreen, nextString: $nextString)
                    
                case .playground:
                    PlaygroundView()
                    
                case .aboutNeos:
                    AboutView()
                    
                }
                
                Spacer()
                
            }
            .background(Color.black)
        }
        
    }
    
    
}

enum Screen: String {
    case main = "Main", learning = "Learning", playground = "Play", aboutNeos = "About"
}
